import React, { useState } from 'react';
import { MarinaProvider, useMarina } from './context/MarinaContext';
import { Navigation } from './components/Navigation';
import { SlipBasinView } from './components/SlipBasinView';
import { BoatClubView } from './components/BoatClubView';
import { MembersRegistryView } from './components/MembersRegistryView';
import { BillingFolioView } from './components/BillingFolioView';
import { HarborMasterView } from './components/HarborMasterView';
import { MemberPortalView } from './components/MemberPortalView';
import { QuickActionModal } from './components/QuickActionModal';
import { Anchor, Radio, Shield, Waves } from 'lucide-react';

const MarinaAppContent: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<string>('basin');
  const [showQuickActionModal, setShowQuickActionModal] = useState<boolean>(false);
  const { activeRole, setActiveRole } = useMarina();

  const handleSelectQuickAction = (actionKey: string) => {
    if (actionKey === 'harbor_fuel' || actionKey === 'harbor_log') {
      setCurrentTab('harbor');
    } else {
      setCurrentTab(actionKey);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      
      {/* Top Navigation conforming to strict top bar contract */}
      <Navigation
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenQuickAction={() => setShowQuickActionModal(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {currentTab === 'basin' && <SlipBasinView />}
        {currentTab === 'fleet' && <BoatClubView />}
        {currentTab === 'members' && <MembersRegistryView />}
        {currentTab === 'billing' && <BillingFolioView />}
        {currentTab === 'harbor' && <HarborMasterView />}
        {currentTab === 'member_portal' && (
          <MemberPortalView
            onNavigateFleet={() => setCurrentTab('fleet')}
            onNavigateBilling={() => setCurrentTab('billing')}
          />
        )}
      </main>

      {/* Quick Action Dispatcher Modal */}
      <QuickActionModal
        isOpen={showQuickActionModal}
        onClose={() => setShowQuickActionModal(false)}
        onSelectAction={handleSelectQuickAction}
      />

      {/* Domain-Appropriate Quiet Marina Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-slate-950/80 px-6 py-4 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Anchor className="w-3.5 h-3.5 text-cyan-500" />
            <span className="font-semibold text-slate-300">Nautica Harbor & Boat Club</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span>Pier Basin Latitude 47°36'N · Longitude 122°20'W</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400 font-mono text-[11px]">
            <span>VHF Ch 16 / Ch 68</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span>Harbor Office: (206) 555-DOCK</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span>USCG Verified Facility</span>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default function App() {
  return (
    <MarinaProvider>
      <MarinaAppContent />
    </MarinaProvider>
  );
}
