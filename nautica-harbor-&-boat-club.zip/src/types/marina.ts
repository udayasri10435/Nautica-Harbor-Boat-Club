export type PierLocation = 
  | 'Pier A (Deep Water)' 
  | 'Pier B (Cruisers)' 
  | 'Pier C (Day Boats)' 
  | 'Pier D (Transient & Fuel)' 
  | 'Dry Stack Rack';

export type SlipStatus = 'occupied' | 'vacant' | 'reserved' | 'maintenance';

export type PowerService = '30A 120V' | '50A 240V' | '100A 3-Phase' | 'Twin 50A';

export interface Slip {
  id: string;
  code: string; // e.g. A-01, B-12
  pier: PierLocation;
  lengthMaxFt: number;
  beamMaxFt: number;
  depthMLLWFt: number;
  powerService: PowerService;
  hasFreshwater: boolean;
  hasPumpout: boolean;
  status: SlipStatus;
  currentVesselId?: string;
  currentMemberId?: string;
  leaseType: 'annual' | 'seasonal' | 'transient' | 'none';
  monthlyRate: number;
  transientDailyRate: number;
  electricMeterLastReading: number; // kWh
  electricMeterCurrentReading: number; // kWh
  lastInspectionDate: string;
  notes?: string;
}

export type VesselType = 
  | 'Motor Yacht' 
  | 'Center Console' 
  | 'Cabin Cruiser' 
  | 'Sailboat' 
  | 'Sportfisher' 
  | 'Tritoon' 
  | 'Catamaran';

export interface Vessel {
  id: string;
  name: string;
  makeModel: string;
  year: number;
  loaFt: number; // Length overall
  beamFt: number;
  draftFt: number;
  registrationNo: string;
  mmsi?: string;
  hullColor: string;
  vesselType: VesselType;
  ownerMemberId: string;
  insuranceCarrier: string;
  insurancePolicyNo: string;
  insuranceExpiry: string;
  insuranceVerified: boolean;
}

export type MemberTier = 
  | 'slip_holder' 
  | 'commodore_club' 
  | 'captain_club' 
  | 'yacht_social' 
  | 'transient_guest';

export interface Member {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  emergencyContact: string;
  memberTier: MemberTier;
  memberSince: string;
  boatLicenceNo: string;
  vhfCallsign?: string;
  balanceDue: number;
  paymentMethodOnFile: {
    type: 'credit_card' | 'ach';
    last4: string;
    brand: string;
  };
  remainingBookingPoints: number;
  assignedSlipId?: string;
  avatarInitials: string;
}

export type BoatClubStatus = 'available' | 'on_water' | 'reserved' | 'maintenance';

export interface ClubBoat {
  id: string;
  name: string;
  model: string;
  year: number;
  lengthFt: number;
  capacity: number;
  engines: string;
  cruisingSpeedKts: number;
  fuelCapacityGal: number;
  currentFuelLevelPct: number;
  engineHours: number;
  homeSlip: string;
  status: BoatClubStatus;
  electronics: string[];
  description: string;
  nextServiceHours: number;
}

export type TimeSlot = 'morning' | 'afternoon' | 'fullday';

export interface FloatPlan {
  destination: string;
  crewCount: number;
  shoreContactName: string;
  shoreContactPhone: string;
  safetyBriefingConfirmed: boolean;
  lifeJacketsCount: number;
  floatPlanNotes?: string;
}

export interface Reservation {
  id: string;
  boatId: string;
  memberId: string;
  date: string;
  timeSlot: TimeSlot;
  departureTime: string;
  estimatedReturnTime: string;
  actualDepartureTime?: string;
  actualReturnTime?: string;
  status: 'confirmed' | 'dispatched' | 'completed' | 'cancelled';
  floatPlan: FloatPlan;
  startingEngineHours?: number;
  returnEngineHours?: number;
  fuelBurnedGal?: number;
  fuelBilledAmount?: number;
  checkinNotes?: string;
}

export interface LineItem {
  id: string;
  description: string;
  category: 'slip_lease' | 'club_dues' | 'electric_kwh' | 'fuel' | 'service' | 'dock_store' | 'transient';
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  memberId: string;
  issueDate: string;
  dueDate: string;
  status: 'paid' | 'pending' | 'overdue';
  lineItems: LineItem[];
  subtotal: number;
  tax: number;
  total: number;
  paymentMethod?: string;
  paidAt?: string;
}

export type HarborEntryType = 
  | 'arrival' 
  | 'departure' 
  | 'weather' 
  | 'maintenance' 
  | 'security' 
  | 'pumpout' 
  | 'fuel_dock';

export interface HarborLog {
  id: string;
  timestamp: string;
  entryType: HarborEntryType;
  message: string;
  recordedBy: string;
  vhfChannel?: string;
  severity: 'nominal' | 'advisory' | 'alert';
}

export interface FuelInventory {
  dieselGallons: number;
  dieselCapacity: number;
  dieselPricePerGal: number;
  gasGallons: number;
  gasCapacity: number;
  gasPricePerGal: number;
  lastDeliveryDate: string;
}

export interface MarineConditions {
  waterTempF: number;
  windSpeedKts: number;
  windDirection: string;
  windGustsKts: number;
  tideState: 'Flooding' | 'Ebbing' | 'Slack High' | 'Slack Low';
  tideHeightFt: number;
  nextTideTime: string;
  nextTideType: 'High' | 'Low';
  nextTideHeightFt: number;
  barometricPressureHpa: number;
  pressureTrend: 'rising' | 'falling' | 'steady';
  harborFlag: 'green' | 'amber' | 'red';
  weatherSummary: string;
}

export interface SlipWaitlistEntry {
  id: string;
  memberId: string;
  preferredPier: PierLocation | 'Any';
  minLOAFt: number;
  requestedDate: string;
  depositPaid: boolean;
  priorityPoints: number;
  vesselName: string;
  vesselType: VesselType;
  notes?: string;
}
