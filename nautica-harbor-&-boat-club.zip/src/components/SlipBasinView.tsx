import React, { useState } from 'react';
import { useMarina } from '../context/MarinaContext';
import { Slip, SlipStatus, PierLocation } from '../types/marina';
import { Modal } from './Modal';
import { 
  Zap, 
  Droplet, 
  Waves, 
  Search, 
  Filter, 
  Compass, 
  FileText, 
  UserCheck, 
  Wrench, 
  LogOut, 
  PlusCircle, 
  CheckCircle2, 
  Clock, 
  Anchor
} from 'lucide-react';

export const SlipBasinView: React.FC = () => {
  const { 
    slips, 
    vessels, 
    members, 
    waitlist, 
    assignSlip, 
    vacateSlip, 
    updateSlipStatus, 
    updateMeterReading, 
    createInvoice,
    removeFromWaitlist 
  } = useMarina();

  // Filters
  const [selectedPier, setSelectedPier] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [minLoaFilter, setMinLoaFilter] = useState<number>(0);
  const [viewMode, setViewMode] = useState<'map' | 'table'>('map');

  // Modals state
  const [activeSlip, setActiveSlip] = useState<Slip | null>(null);
  const [showAssignModal, setShowAssignModal] = useState<boolean>(false);
  const [showMeterModal, setShowMeterModal] = useState<boolean>(false);
  const [showWaitlistModal, setShowWaitlistModal] = useState<boolean>(false);

  // Form states for assignment
  const [assignVesselId, setAssignVesselId] = useState<string>('');
  const [assignMemberId, setAssignMemberId] = useState<string>('');
  const [assignLeaseType, setAssignLeaseType] = useState<'annual' | 'seasonal' | 'transient'>('annual');
  const [assignRate, setAssignRate] = useState<number>(0);

  // Meter update form
  const [newMeterValue, setNewMeterValue] = useState<number>(0);

  const piers: PierLocation[] = [
    'Pier A (Deep Water)',
    'Pier B (Cruisers)',
    'Pier C (Day Boats)',
    'Pier D (Transient & Fuel)',
    'Dry Stack Rack'
  ];

  // Filtering
  const filteredSlips = slips.filter(slip => {
    if (selectedPier !== 'All' && slip.pier !== selectedPier) return false;
    if (statusFilter !== 'all' && slip.status !== statusFilter) return false;
    if (minLoaFilter > 0 && slip.lengthMaxFt < minLoaFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const vessel = vessels.find(v => v.id === slip.currentVesselId);
      const member = members.find(m => m.id === slip.currentMemberId);
      const matchCode = slip.code.toLowerCase().includes(q);
      const matchVessel = vessel?.name.toLowerCase().includes(q) || vessel?.makeModel.toLowerCase().includes(q);
      const matchMember = member?.fullName.toLowerCase().includes(q);
      if (!matchCode && !matchVessel && !matchMember) return false;
    }

    return true;
  });

  // Basin stats
  const totalSlipsCount = slips.length;
  const occupiedCount = slips.filter(s => s.status === 'occupied').length;
  const vacantCount = slips.filter(s => s.status === 'vacant').length;
  const reservedCount = slips.filter(s => s.status === 'reserved').length;
  const maintenanceCount = slips.filter(s => s.status === 'maintenance').length;
  const occupancyPct = Math.round((occupiedCount / totalSlipsCount) * 100);
  const totalMonthlySlipRevenue = slips
    .filter(s => s.status === 'occupied')
    .reduce((sum, s) => sum + s.monthlyRate, 0);

  const handleOpenSlip = (slip: Slip) => {
    setActiveSlip(slip);
  };

  const handleStartAssign = (slip: Slip) => {
    setActiveSlip(slip);
    setAssignRate(slip.monthlyRate);
    // Auto-select first member who doesn't have an assigned slip, or first member
    const unassignedMember = members.find(m => !m.assignedSlipId) || members[0];
    if (unassignedMember) {
      setAssignMemberId(unassignedMember.id);
      const memberVessels = vessels.filter(v => v.ownerMemberId === unassignedMember.id);
      if (memberVessels.length > 0) {
        setAssignVesselId(memberVessels[0].id);
      } else {
        setAssignVesselId(vessels[0]?.id || '');
      }
    }
    setShowAssignModal(true);
  };

  const handleExecuteAssign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSlip || !assignMemberId) return;

    assignSlip(activeSlip.id, assignVesselId, assignMemberId, assignLeaseType, Number(assignRate));
    setShowAssignModal(false);
    // Refresh active slip
    const updated = slips.find(s => s.id === activeSlip.id);
    if (updated) {
      setActiveSlip({
        ...updated,
        status: 'occupied',
        currentVesselId: assignVesselId,
        currentMemberId: assignMemberId,
        leaseType: assignLeaseType,
        monthlyRate: Number(assignRate)
      });
    }
  };

  const handleUpdateMeter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSlip) return;
    updateMeterReading(activeSlip.id, Number(newMeterValue));
    setShowMeterModal(false);
    setActiveSlip({
      ...activeSlip,
      electricMeterLastReading: activeSlip.electricMeterCurrentReading,
      electricMeterCurrentReading: Number(newMeterValue)
    });
  };

  const getStatusStyle = (status: SlipStatus) => {
    switch (status) {
      case 'occupied':
        return {
          border: 'border-cyan-500/50 bg-cyan-950/20 text-cyan-300',
          dot: 'bg-cyan-400',
          label: 'Occupied'
        };
      case 'vacant':
        return {
          border: 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300',
          dot: 'bg-emerald-400',
          label: 'Vacant'
        };
      case 'reserved':
        return {
          border: 'border-amber-500/40 bg-amber-950/20 text-amber-300',
          dot: 'bg-amber-400',
          label: 'Reserved'
        };
      case 'maintenance':
        return {
          border: 'border-rose-500/40 bg-rose-950/20 text-rose-300',
          dot: 'bg-rose-400',
          label: 'Maintenance'
        };
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Overview & Metric Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Basin Occupancy</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">{occupancyPct}%</span>
            <span className="text-xs text-slate-400 font-mono tabular-nums">{occupiedCount} / {totalSlipsCount} berths</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2.5 overflow-hidden">
            <div 
              className="bg-cyan-500 h-full rounded-full transition-all" 
              style={{ width: `${occupancyPct}%` }} 
            />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Available Berths</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-emerald-400">{vacantCount}</span>
            <span className="text-xs text-slate-400 font-mono tabular-nums">Ready for assignment</span>
          </div>
          <div className="text-xs text-slate-400 mt-2 flex items-center gap-2">
            <span>{reservedCount} Reserved</span>
            <span aria-hidden="true">·</span>
            <span>{maintenanceCount} Haul / Maint</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Monthly Slip Revenue</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">
              ${totalMonthlySlipRevenue.toLocaleString()}
            </span>
            <span className="text-xs text-cyan-400 font-mono">MRR</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Avg berth: ${Math.round(totalMonthlySlipRevenue / Math.max(1, occupiedCount)).toLocaleString()} / mo
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-400">Slip Waitlist</div>
            <button
              onClick={() => setShowWaitlistModal(true)}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
            >
              View Roster →
            </button>
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-amber-400">{waitlist.length}</span>
            <span className="text-xs text-slate-400 font-mono">Vessels awaiting</span>
          </div>
          <div className="text-xs text-slate-400 mt-2 truncate">
            Top: {waitlist[0]?.vesselName || 'None'} ({waitlist[0]?.minLOAFt}ft)
          </div>
        </div>
      </div>

      {/* Basin Control Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          
          {/* Pier Selector (Button group with working handlers) */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 lg:pb-0">
            <button
              onClick={() => setSelectedPier('All')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                selectedPier === 'All'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
              }`}
            >
              All Basins ({slips.length})
            </button>
            {piers.map(pier => {
              const count = slips.filter(s => s.pier === pier).length;
              return (
                <button
                  key={pier}
                  onClick={() => setSelectedPier(pier)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                    selectedPier === pier
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
                  }`}
                >
                  {pier.split(' (')[0]} ({count})
                </button>
              );
            })}
          </div>

          {/* Search & Layout toggle */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 lg:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search slip, vessel, or member..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-100 rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs">
              <button
                onClick={() => setViewMode('map')}
                className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                  viewMode === 'map' ? 'bg-slate-800 text-cyan-400' : 'text-slate-400 hover:text-white'
                }`}
              >
                Map
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                  viewMode === 'table' ? 'bg-slate-800 text-cyan-400' : 'text-slate-400 hover:text-white'
                }`}
              >
                Roster
              </button>
            </div>
          </div>
        </div>

        {/* Secondary filters row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Filter className="w-3 h-3 text-slate-400" />
            <span>Status:</span>
            {['all', 'occupied', 'vacant', 'reserved', 'maintenance'].map(status => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`capitalize cursor-pointer ${
                  statusFilter === status ? 'text-cyan-400 font-semibold underline' : 'hover:text-slate-200'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <span>Min LOA:</span>
            <input
              type="range"
              min="0"
              max="80"
              step="5"
              value={minLoaFilter}
              onChange={e => setMinLoaFilter(Number(e.target.value))}
              className="accent-cyan-500 w-24 cursor-pointer"
            />
            <span className="font-mono tabular-nums text-slate-200">{minLoaFilter > 0 ? `${minLoaFilter}ft+` : 'Any'}</span>
            {minLoaFilter > 0 && (
              <button onClick={() => setMinLoaFilter(0)} className="text-slate-500 hover:text-slate-300">
                Reset
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Basin Grid / Roster */}
      {viewMode === 'map' ? (
        <div className="space-y-6">
          
          {/* Visual pier layout group */}
          {piers
            .filter(p => selectedPier === 'All' || selectedPier === p)
            .map(pierName => {
              const pierSlips = filteredSlips.filter(s => s.pier === pierName);
              if (pierSlips.length === 0) return null;

              return (
                <div key={pierName} className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                  
                  {/* Pier Header */}
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
                      <h3 className="text-sm font-semibold text-white tracking-tight">{pierName}</h3>
                      <span className="text-xs text-slate-400 font-mono tabular-nums">
                        {pierSlips.filter(s => s.status === 'occupied').length} / {pierSlips.length} occupied
                      </span>
                    </div>

                    <div className="flex items-center gap-4 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <Waves className="w-3.5 h-3.5 text-cyan-500" /> 
                        MLLW: {pierSlips[0]?.depthMLLWFt > 0 ? `${pierSlips[0]?.depthMLLWFt}ft` : 'Dry Rack'}
                      </span>
                      <span className="flex items-center gap-1">
                        <Zap className="w-3.5 h-3.5 text-amber-400" /> 
                        {pierSlips[0]?.powerService}
                      </span>
                    </div>
                  </div>

                  {/* Slips Water Berth Diagram */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3.5">
                    {pierSlips.map(slip => {
                      const vessel = vessels.find(v => v.id === slip.currentVesselId);
                      const member = members.find(m => m.id === slip.currentMemberId);
                      const st = getStatusStyle(slip.status);

                      return (
                        <div
                          key={slip.id}
                          onClick={() => handleOpenSlip(slip)}
                          className={`group relative p-3.5 rounded-lg border transition-all cursor-pointer hover:border-cyan-400/80 hover:shadow-lg hover:shadow-cyan-950/20 ${st.border}`}
                        >
                          {/* Berth Head */}
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-bold font-mono tracking-tight text-white group-hover:text-cyan-300">
                              {slip.code}
                            </span>
                            <div className="flex items-center gap-1.5 text-xs">
                              <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                              <span className="text-xs font-medium capitalize">{st.label}</span>
                            </div>
                          </div>

                          {/* Dimensions & Depth */}
                          <div className="flex items-center gap-2 text-xs text-slate-400 font-mono tabular-nums">
                            <span>Max {slip.lengthMaxFt}ft</span>
                            <span aria-hidden="true">·</span>
                            <span>Beam {slip.beamMaxFt}ft</span>
                            {slip.depthMLLWFt > 0 && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span>{slip.depthMLLWFt}ft draft</span>
                              </>
                            )}
                          </div>

                          {/* Occupant / Vessel Information */}
                          <div className="mt-3 pt-2 border-t border-slate-800/80 min-h-[50px] flex flex-col justify-center">
                            {slip.status === 'occupied' && vessel ? (
                              <div>
                                <div className="text-xs font-semibold text-white truncate flex items-center gap-1.5">
                                  <Anchor className="w-3 h-3 text-cyan-400 shrink-0" />
                                  <span className="truncate">{vessel.name}</span>
                                </div>
                                <div className="text-xs text-slate-400 truncate mt-0.5">
                                  {vessel.loaFt}ft {vessel.makeModel}
                                </div>
                                <div className="text-[11px] text-slate-400 truncate mt-0.5">
                                  {member?.fullName || 'Slip Holder'}
                                </div>
                              </div>
                            ) : slip.status === 'vacant' ? (
                              <div className="flex items-center justify-between text-xs text-emerald-400/90 font-medium">
                                <span>Ready for berthing</span>
                                <span className="font-mono tabular-nums">${slip.monthlyRate}/mo</span>
                              </div>
                            ) : slip.status === 'reserved' ? (
                              <div className="text-xs text-amber-400/90">
                                <div className="font-medium">Advance Reservation</div>
                                <div className="text-[11px] text-slate-400 mt-0.5 truncate">{slip.notes || 'Arriving shortly'}</div>
                              </div>
                            ) : (
                              <div className="text-xs text-rose-400/90">
                                <div className="font-medium flex items-center gap-1">
                                  <Wrench className="w-3 h-3" /> Dock Maintenance
                                </div>
                                <div className="text-[11px] text-slate-400 mt-0.5 truncate">{slip.notes || 'Service in progress'}</div>
                              </div>
                            )}
                          </div>

                          {/* Pedestal & Utilities Indicators */}
                          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-800/60">
                            <span className="flex items-center gap-1 font-mono">
                              <Zap className="w-3 h-3 text-amber-400" />
                              {slip.powerService.split(' ')[0]}
                            </span>
                            <div className="flex items-center gap-1.5">
                              {slip.hasFreshwater && (
                                <span title="Freshwater hookup">
                                  <Droplet className="w-3 h-3 text-cyan-400" />
                                </span>
                              )}
                              {slip.hasPumpout && (
                                <span title="In-slip pumpout">
                                  <Waves className="w-3 h-3 text-emerald-400" />
                                </span>
                              )}
                              <span className="font-mono text-slate-400">
                                ${slip.transientDailyRate}/day
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
        </div>
      ) : (
        /* Tabular Roster View */
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950 text-slate-400 font-semibold">
                  <th className="py-3 px-4">Slip</th>
                  <th className="py-3 px-4">Pier Basin</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Max LOA / Beam</th>
                  <th className="py-3 px-4">Depth MLLW</th>
                  <th className="py-3 px-4">Vessel Berthed</th>
                  <th className="py-3 px-4">Member / Lease</th>
                  <th className="py-3 px-4 text-right">Electric Meter</th>
                  <th className="py-3 px-4 text-right">Monthly Rate</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredSlips.map(slip => {
                  const vessel = vessels.find(v => v.id === slip.currentVesselId);
                  const member = members.find(m => m.id === slip.currentMemberId);
                  const st = getStatusStyle(slip.status);

                  return (
                    <tr 
                      key={slip.id}
                      onClick={() => handleOpenSlip(slip)}
                      className="hover:bg-slate-800/50 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-white">{slip.code}</td>
                      <td className="py-3 px-4 text-slate-400">{slip.pier.split(' (')[0]}</td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center gap-1.5 font-medium capitalize">
                          <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                          {slip.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-300">{slip.lengthMaxFt}ft × {slip.beamMaxFt}ft</td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-400">{slip.depthMLLWFt > 0 ? `${slip.depthMLLWFt}ft` : 'Rack'}</td>
                      <td className="py-3 px-4">
                        {vessel ? (
                          <div>
                            <span className="font-semibold text-white">{vessel.name}</span>
                            <span className="text-slate-400 text-[11px] block">{vessel.makeModel}</span>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">None</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {member ? (
                          <div>
                            <span className="text-slate-200">{member.fullName}</span>
                            <span className="text-slate-400 text-[11px] block capitalize">{slip.leaseType} lease</span>
                          </div>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-300">
                        {slip.electricMeterCurrentReading.toLocaleString()} kWh
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-white">
                        ${slip.monthlyRate.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenSlip(slip);
                          }}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded text-xs font-medium cursor-pointer"
                        >
                          Manage
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Slip Detail Drawer / Modal */}
      {activeSlip && (
        <Modal
          isOpen={!!activeSlip && !showAssignModal && !showMeterModal}
          onClose={() => setActiveSlip(null)}
          title={`Berth Slip ${activeSlip.code} Specification`}
          subtitle={`${activeSlip.pier} · Max Vessel Length ${activeSlip.lengthMaxFt}ft LOA`}
        >
          <div className="space-y-5">
            
            {/* Status & Quick Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950 p-3.5 rounded-lg border border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 block">Current Status</span>
                <span className="font-semibold capitalize text-white mt-0.5 block flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${getStatusStyle(activeSlip.status).dot}`} />
                  {activeSlip.status}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Max Beam & Draft</span>
                <span className="font-mono tabular-nums text-slate-200 mt-0.5 block">
                  {activeSlip.beamMaxFt}ft / {activeSlip.depthMLLWFt}ft MLLW
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Shore Power</span>
                <span className="font-mono text-amber-400 mt-0.5 block">
                  {activeSlip.powerService}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Monthly Rate</span>
                <span className="font-mono font-bold text-cyan-400 mt-0.5 block">
                  ${activeSlip.monthlyRate.toLocaleString()} / mo
                </span>
              </div>
            </div>

            {/* Current Berth Occupant Details */}
            <div className="border border-slate-800 rounded-lg p-4 bg-slate-900/50 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Berthed Vessel & Leaseholder
                </h4>
                {activeSlip.status === 'occupied' && (
                  <button
                    onClick={() => {
                      if (confirm(`Vacate slip ${activeSlip.code} and record departure?`)) {
                        vacateSlip(activeSlip.id);
                        setActiveSlip({
                          ...activeSlip,
                          status: 'vacant',
                          currentVesselId: undefined,
                          currentMemberId: undefined,
                          leaseType: 'none'
                        });
                      }
                    }}
                    className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" /> Vacate Slip
                  </button>
                )}
              </div>

              {activeSlip.status === 'occupied' ? (
                (() => {
                  const vessel = vessels.find(v => v.id === activeSlip.currentVesselId);
                  const member = members.find(m => m.id === activeSlip.currentMemberId);
                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1.5">
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                          <Anchor className="w-4 h-4 text-cyan-400" />
                          {vessel?.name || 'Vessel'}
                        </div>
                        <div className="text-slate-300 font-mono tabular-nums">
                          {vessel?.loaFt}ft LOA · Beam {vessel?.beamFt}ft · Draft {vessel?.draftFt}ft
                        </div>
                        <div className="text-slate-400">
                          {vessel?.year} {vessel?.makeModel} ({vessel?.vesselType})
                        </div>
                        <div className="text-slate-400 font-mono">
                          Reg #{vessel?.registrationNo} {vessel?.mmsi && `· MMSI: ${vessel.mmsi}`}
                        </div>
                        <div className="text-xs text-emerald-400 flex items-center gap-1 pt-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Insurance: {vessel?.insuranceCarrier} (Exp: {vessel?.insuranceExpiry})</span>
                        </div>
                      </div>

                      <div className="space-y-1.5 border-t md:border-t-0 md:border-l border-slate-800 pt-3 md:pt-0 md:pl-4">
                        <div className="font-semibold text-white">{member?.fullName}</div>
                        <div className="text-slate-300 font-mono">{member?.phone}</div>
                        <div className="text-slate-400">{member?.email}</div>
                        <div className="text-slate-400 font-mono text-[11px]">
                          VHF Callsign: {member?.vhfCallsign || 'None registered'}
                        </div>
                        <div className="text-xs text-slate-300 pt-1">
                          Lease Contract: <span className="text-cyan-400 font-medium capitalize">{activeSlip.leaseType}</span> · Renews Oct 2026
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : (
                <div className="text-center py-6 text-slate-400 space-y-3">
                  <p className="text-xs">This slip is currently not assigned to any permanent or transient vessel.</p>
                  <button
                    onClick={() => handleStartAssign(activeSlip)}
                    className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-semibold rounded-lg transition-colors cursor-pointer inline-flex items-center gap-2"
                  >
                    <PlusCircle className="w-4 h-4" /> Assign Vessel & Create Lease
                  </button>
                </div>
              )}
            </div>

            {/* Shore Power Pedestal & Meter Reading */}
            <div className="border border-slate-800 rounded-lg p-4 bg-slate-900/50 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Pedestal Electric Utility Meter
                  </h4>
                </div>
                <button
                  onClick={() => {
                    setNewMeterValue(activeSlip.electricMeterCurrentReading);
                    setShowMeterModal(true);
                  }}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
                >
                  Log Reading →
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3 text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div>
                  <span className="text-slate-400 block">Last Billed</span>
                  <span className="font-mono tabular-nums text-slate-300 font-semibold mt-0.5 block">
                    {activeSlip.electricMeterLastReading.toLocaleString()} kWh
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Current Reading</span>
                  <span className="font-mono tabular-nums text-white font-semibold mt-0.5 block">
                    {activeSlip.electricMeterCurrentReading.toLocaleString()} kWh
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Cycle Consumption</span>
                  <span className="font-mono tabular-nums text-amber-400 font-semibold mt-0.5 block">
                    +{(activeSlip.electricMeterCurrentReading - activeSlip.electricMeterLastReading).toLocaleString()} kWh
                    <span className="text-slate-400 text-[11px] font-normal ml-1">
                      (${((activeSlip.electricMeterCurrentReading - activeSlip.electricMeterLastReading) * 0.22).toFixed(2)})
                    </span>
                  </span>
                </div>
              </div>
            </div>

            {/* Notes & Operational Status Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">Set Berth Status:</span>
                {(['occupied', 'vacant', 'reserved', 'maintenance'] as SlipStatus[]).map(st => (
                  <button
                    key={st}
                    onClick={() => {
                      updateSlipStatus(activeSlip.id, st);
                      setActiveSlip({ ...activeSlip, status: st });
                    }}
                    className={`px-2 py-1 rounded text-xs capitalize cursor-pointer transition-colors ${
                      activeSlip.status === st
                        ? 'bg-slate-700 text-white font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>

              {activeSlip.status === 'occupied' && (
                <button
                  onClick={() => {
                    if (activeSlip.currentMemberId) {
                      createInvoice(
                        activeSlip.currentMemberId,
                        [
                          {
                            description: `Monthly Berth Lease - Slip ${activeSlip.code} (${activeSlip.lengthMaxFt}ft)`,
                            category: 'slip_lease',
                            quantity: 1,
                            unitPrice: activeSlip.monthlyRate
                          },
                          {
                            description: `Metered Power Utility (${activeSlip.electricMeterCurrentReading - activeSlip.electricMeterLastReading} kWh @ $0.22)`,
                            category: 'electric_kwh',
                            quantity: Math.max(0, activeSlip.electricMeterCurrentReading - activeSlip.electricMeterLastReading),
                            unitPrice: 0.22
                          }
                        ],
                        new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]
                      );
                      alert(`Monthly folio invoice generated for Slip ${activeSlip.code}!`);
                    }
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded font-medium cursor-pointer"
                >
                  Generate Folio Bill
                </button>
              )}
            </div>

          </div>
        </Modal>
      )}

      {/* Assign Vessel Modal */}
      {showAssignModal && activeSlip && (
        <Modal
          isOpen={showAssignModal}
          onClose={() => setShowAssignModal(false)}
          title={`Assign Vessel to Slip ${activeSlip.code}`}
          subtitle={`${activeSlip.pier} · Max Capacity ${activeSlip.lengthMaxFt}ft LOA`}
        >
          <form onSubmit={handleExecuteAssign} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Select Member / Slip Holder</label>
              <select
                value={assignMemberId}
                onChange={e => {
                  setAssignMemberId(e.target.value);
                  const memVessels = vessels.filter(v => v.ownerMemberId === e.target.value);
                  if (memVessels.length > 0) setAssignVesselId(memVessels[0].id);
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
                required
              >
                {members.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.fullName} ({m.memberTier.replace('_', ' ')})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Select Vessel</label>
              <select
                value={assignVesselId}
                onChange={e => setAssignVesselId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
                required
              >
                {vessels
                  .filter(v => !assignMemberId || v.ownerMemberId === assignMemberId)
                  .map(v => (
                    <option key={v.id} value={v.id}>
                      {v.name} - {v.loaFt}ft {v.makeModel} (Reg #{v.registrationNo})
                    </option>
                  ))}
                {/* Fallback to all vessels if member has none */}
                {vessels.filter(v => v.ownerMemberId === assignMemberId).length === 0 &&
                  vessels.map(v => (
                    <option key={v.id} value={v.id}>
                      {v.name} - {v.loaFt}ft {v.makeModel}
                    </option>
                  ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Lease Agreement Type</label>
                <select
                  value={assignLeaseType}
                  onChange={e => setAssignLeaseType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
                >
                  <option value="annual">Annual Lease (12 Months)</option>
                  <option value="seasonal">Seasonal (6 Months)</option>
                  <option value="transient">Transient / Guest Stay</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Monthly Berth Rate ($ USD)</label>
                <input
                  type="number"
                  value={assignRate}
                  onChange={e => setAssignRate(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>
            </div>

            <div className="p-3 bg-cyan-950/20 border border-cyan-800/40 rounded-lg text-slate-300 text-[11px] space-y-1">
              <div className="font-semibold text-cyan-300">Harbor Master Compliance Check:</div>
              <div>• Slip Max LOA: {activeSlip.lengthMaxFt}ft (Vessel must not exceed clearance)</div>
              <div>• Marine Insurance with minimum $500,000 liability must remain active.</div>
              <div>• Shore power pedestal meter initialized to {activeSlip.electricMeterCurrentReading} kWh.</div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAssignModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer"
              >
                Confirm Berth Assignment
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Meter Reading Modal */}
      {showMeterModal && activeSlip && (
        <Modal
          isOpen={showMeterModal}
          onClose={() => setShowMeterModal(false)}
          title={`Log Electric Meter for Slip ${activeSlip.code}`}
          subtitle={`Previous reading: ${activeSlip.electricMeterCurrentReading} kWh`}
        >
          <form onSubmit={handleUpdateMeter} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1">New Pedestal Meter Value (kWh)</label>
              <input
                type="number"
                min={activeSlip.electricMeterCurrentReading}
                value={newMeterValue}
                onChange={e => setNewMeterValue(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-base font-mono text-white focus:outline-none focus:border-cyan-500"
                required
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Usage delta: +{Math.max(0, newMeterValue - activeSlip.electricMeterCurrentReading)} kWh 
                (${((newMeterValue - activeSlip.electricMeterCurrentReading) * 0.22).toFixed(2)})
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowMeterModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer"
              >
                Save Meter Reading
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Slip Waitlist Modal */}
      {showWaitlistModal && (
        <Modal
          isOpen={showWaitlistModal}
          onClose={() => setShowWaitlistModal(false)}
          title="Marina Berth Waitlist Roster"
          subtitle="Ranked queue for annual & seasonal slip allocations"
        >
          <div className="space-y-4 text-xs">
            {waitlist.length === 0 ? (
              <p className="text-slate-400 text-center py-6">No members currently waiting for slips.</p>
            ) : (
              <div className="divide-y divide-slate-800 border border-slate-800 rounded-lg overflow-hidden">
                {waitlist.map((entry, idx) => {
                  const member = members.find(m => m.id === entry.memberId);
                  return (
                    <div key={entry.id} className="p-3.5 bg-slate-900/60 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center font-mono font-bold text-amber-400 text-xs">
                          #{idx + 1}
                        </span>
                        <div>
                          <div className="font-semibold text-white">
                            {entry.vesselName} ({entry.minLOAFt}ft {entry.vesselType})
                          </div>
                          <div className="text-slate-400 text-[11px]">
                            {member?.fullName || 'Member'} · Preferred: {entry.preferredPier}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-right">
                        <div>
                          <span className="text-slate-400 block text-[11px]">Priority Points</span>
                          <span className="font-mono text-cyan-400 font-bold">{entry.priorityPoints} pts</span>
                        </div>
                        <button
                          onClick={() => {
                            if (confirm(`Remove ${entry.vesselName} from the waitlist?`)) {
                              removeFromWaitlist(entry.id);
                            }
                          }}
                          className="text-xs text-rose-400 hover:text-rose-300 cursor-pointer"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </Modal>
      )}

    </div>
  );
};
