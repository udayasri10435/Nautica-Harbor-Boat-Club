import React from 'react';
import { Modal } from './Modal';
import { 
  Anchor, 
  Ship, 
  UserPlus, 
  Receipt, 
  Fuel, 
  Clock, 
  ArrowRight 
} from 'lucide-react';

interface QuickActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAction: (actionKey: string) => void;
}

export const QuickActionModal: React.FC<QuickActionModalProps> = ({
  isOpen,
  onClose,
  onSelectAction
}) => {
  const actions = [
    {
      id: 'basin',
      title: 'Assign Slip / Berth Lease',
      desc: 'Allocate deep water, cruiser, or transient berth to vessel.',
      icon: Anchor,
      color: 'text-cyan-400 bg-cyan-950/40 border-cyan-800/60'
    },
    {
      id: 'fleet',
      title: 'Book Club Fleet Vessel',
      desc: 'Schedule day cruiser or center console and file USCG float plan.',
      icon: Ship,
      color: 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60'
    },
    {
      id: 'members',
      title: 'Onboard Member & Vessel',
      desc: 'Add member profile, boater education card, and marine insurance.',
      icon: UserPlus,
      color: 'text-blue-400 bg-blue-950/40 border-blue-800/60'
    },
    {
      id: 'billing',
      title: 'Generate Folio Invoice',
      desc: 'Bill slip rent, metered power kWh, fuel, detailing, or repairs.',
      icon: Receipt,
      color: 'text-amber-400 bg-amber-950/40 border-amber-800/60'
    },
    {
      id: 'harbor_fuel',
      title: 'Dispense Marine Fuel Float',
      desc: 'Dispense ValvTect Diesel or Rec-90 Gas and charge slip folio.',
      icon: Fuel,
      color: 'text-amber-500 bg-amber-950/40 border-amber-800/60'
    },
    {
      id: 'harbor_log',
      title: 'Log Harbor Master Entry',
      desc: 'Record vessel arrival/departure hail or VHF weather warning.',
      icon: Clock,
      color: 'text-purple-400 bg-purple-950/40 border-purple-800/60'
    }
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Quick Marina & Club Operations"
      subtitle="Select an operational workflow to dispatch immediately"
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        {actions.map(act => {
          const Icon = act.icon;
          return (
            <button
              key={act.id}
              onClick={() => {
                onClose();
                onSelectAction(act.id);
              }}
              className="p-3.5 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-lg text-left transition-all hover:scale-[1.01] cursor-pointer flex items-start gap-3 group"
            >
              <div className={`p-2 rounded-lg border shrink-0 ${act.color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-white group-hover:text-cyan-300 flex items-center justify-between">
                  <span>{act.title}</span>
                  <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
                </div>
                <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed">
                  {act.desc}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </Modal>
  );
};
