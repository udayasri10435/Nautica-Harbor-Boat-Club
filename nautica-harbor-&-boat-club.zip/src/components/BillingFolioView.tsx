import React, { useState } from 'react';
import { useMarina } from '../context/MarinaContext';
import { Invoice, Member, LineItem } from '../types/marina';
import { Modal } from './Modal';
import { 
  DollarSign, 
  Receipt, 
  FileText, 
  Plus, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  CreditCard, 
  Printer, 
  ArrowUpRight, 
  Zap, 
  Fuel, 
  Ship,
  Calendar
} from 'lucide-react';

export const BillingFolioView: React.FC = () => {
  const { invoices, members, createInvoice, markInvoicePaid } = useMarina();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [showNewInvoiceModal, setShowNewInvoiceModal] = useState<boolean>(false);
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false);
  const [paymentMethodSelect, setPaymentMethodSelect] = useState<string>('Visa on file (...4192)');

  // New Invoice Form
  const [invMemberId, setInvMemberId] = useState<string>(members[0]?.id || '');
  const [invDueDate, setInvDueDate] = useState<string>(
    new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]
  );
  const [lineItems, setLineItems] = useState<{ description: string; category: any; quantity: number; unitPrice: number }[]>([
    { description: 'Monthly Berth Lease Fee', category: 'slip_lease', quantity: 1, unitPrice: 1850.00 }
  ]);

  const filteredInvoices = invoices.filter(inv => {
    if (statusFilter !== 'all' && inv.status !== statusFilter) return false;
    return true;
  });

  // Financial aggregates
  const totalBilled = invoices.reduce((sum, inv) => sum + inv.total, 0);
  const totalPaid = invoices.filter(inv => inv.status === 'paid').reduce((sum, inv) => sum + inv.total, 0);
  const totalPending = invoices.filter(inv => inv.status === 'pending').reduce((sum, inv) => sum + inv.total, 0);
  const totalOverdue = invoices.filter(inv => inv.status === 'overdue').reduce((sum, inv) => sum + inv.total, 0);

  const handleAddLineItem = () => {
    setLineItems(prev => [
      ...prev,
      { description: 'Metered Utility / Shore Power', category: 'electric_kwh', quantity: 150, unitPrice: 0.22 }
    ]);
  };

  const handleRemoveLineItem = (index: number) => {
    if (lineItems.length === 1) return;
    setLineItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdateLineItem = (index: number, field: string, value: any) => {
    setLineItems(prev =>
      prev.map((item, i) => (i === index ? { ...item, [field]: value } : item))
    );
  };

  const handleCreateInvoiceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!invMemberId || lineItems.length === 0) return;

    createInvoice(invMemberId, lineItems, invDueDate);
    setShowNewInvoiceModal(false);
  };

  const handleRecordPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice) return;
    markInvoicePaid(selectedInvoice.id, paymentMethodSelect);
    setShowPaymentModal(false);
    setSelectedInvoice(null);
  };

  const getStatusBadge = (status: 'paid' | 'pending' | 'overdue') => {
    switch (status) {
      case 'paid':
        return { text: 'Paid', dot: 'bg-emerald-400', color: 'text-emerald-400' };
      case 'pending':
        return { text: 'Pending', dot: 'bg-cyan-400', color: 'text-cyan-400' };
      case 'overdue':
        return { text: 'Overdue', dot: 'bg-rose-400', color: 'text-rose-400' };
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Financial Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Total Billed Folios</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">
              ${totalBilled.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Current billing cycle
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Collected Revenue</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-emerald-400">
              ${totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="text-xs text-slate-400 mt-2 font-mono tabular-nums">
            {Math.round((totalPaid / Math.max(1, totalBilled)) * 100)}% collection rate
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Pending Receivables</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-cyan-400">
              ${totalPending.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Auto-debit scheduled
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Overdue Balances</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-rose-400">
              ${totalOverdue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="text-xs text-rose-400/80 mt-2">
            Requires dockmaster follow-up
          </div>
        </div>
      </div>

      {/* Control bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {['all', 'pending', 'paid', 'overdue'].map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg capitalize transition-colors cursor-pointer ${
                statusFilter === st
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
              }`}
            >
              {st} ({invoices.filter(i => st === 'all' || i.status === st).length})
            </button>
          ))}
        </div>

        <button
          onClick={() => setShowNewInvoiceModal(true)}
          className="px-3.5 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
        >
          <Plus className="w-4 h-4" /> Create Folio Invoice
        </button>
      </div>

      {/* Invoices List */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950 text-slate-400 font-semibold">
                <th className="py-3 px-4">Invoice #</th>
                <th className="py-3 px-4">Member / Folio</th>
                <th className="py-3 px-4">Issue Date</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4">Item Highlights</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredInvoices.map(inv => {
                const member = members.find(m => m.id === inv.memberId);
                const st = getStatusBadge(inv.status);

                return (
                  <tr
                    key={inv.id}
                    onClick={() => setSelectedInvoice(inv)}
                    className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4 font-mono font-bold text-white">{inv.invoiceNumber}</td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white">{member?.fullName}</div>
                      <div className="text-slate-400 text-[11px]">{member?.email}</div>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-400">{inv.issueDate}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-400">{inv.dueDate}</td>
                    <td className="py-3 px-4">
                      <div className="text-slate-200 truncate max-w-xs">{inv.lineItems[0]?.description}</div>
                      {inv.lineItems.length > 1 && (
                        <div className="text-slate-400 text-[11px]">
                          +{inv.lineItems.length - 1} additional charges (utilities/fuel)
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-white">
                      ${inv.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center gap-1.5 font-medium ${st.color}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                        {st.text}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedInvoice(inv);
                        }}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded text-xs cursor-pointer font-medium"
                      >
                        View Folio
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Detail Modal / Official Printable Marine Folio */}
      {selectedInvoice && (
        <Modal
          isOpen={!!selectedInvoice && !showPaymentModal}
          onClose={() => setSelectedInvoice(null)}
          title={`Marina Statement: ${selectedInvoice.invoiceNumber}`}
          subtitle={`Issue Date: ${selectedInvoice.issueDate} · Due Date: ${selectedInvoice.dueDate}`}
        >
          {(() => {
            const member = members.find(m => m.id === selectedInvoice.memberId);
            const st = getStatusBadge(selectedInvoice.status);

            return (
              <div className="space-y-5 text-xs">
                
                {/* Official Marina Billhead */}
                <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="text-sm font-bold text-white tracking-wide">
                      NAUTICA HARBOR & YACHT CLUB
                    </div>
                    <div className="text-slate-400 text-[11px] mt-0.5">
                      Berth Basin Pier Office · VHF Ch 16 / Ch 68 · USCG Facility #8419-A
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-slate-400 text-[11px] block">Folio Status</span>
                    <span className={`font-semibold capitalize text-sm flex items-center justify-end gap-1.5 ${st.color}`}>
                      <span className={`w-2 h-2 rounded-full ${st.dot}`} />
                      {st.text}
                    </span>
                  </div>
                </div>

                {/* Bill-To Member details */}
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[11px] uppercase tracking-wider font-semibold">
                      Account / Billed To
                    </span>
                    <div className="font-semibold text-white mt-1">{member?.fullName}</div>
                    <div className="text-slate-300">{member?.email}</div>
                    <div className="text-slate-400 font-mono text-[11px]">{member?.phone}</div>
                  </div>

                  <div className="text-right">
                    <span className="text-slate-400 block text-[11px] uppercase tracking-wider font-semibold">
                      Payment Terms
                    </span>
                    <div className="text-slate-200 mt-1">Due by {selectedInvoice.dueDate}</div>
                    {selectedInvoice.paidAt && (
                      <div className="text-emerald-400 font-mono text-[11px]">
                        Paid on {selectedInvoice.paidAt} via {selectedInvoice.paymentMethod}
                      </div>
                    )}
                  </div>
                </div>

                {/* Line Items Table */}
                <div className="border border-slate-800 rounded-lg overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-semibold">
                        <th className="py-2.5 px-3">Service / Charge Description</th>
                        <th className="py-2.5 px-3 text-right">Qty</th>
                        <th className="py-2.5 px-3 text-right">Unit Rate</th>
                        <th className="py-2.5 px-3 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-300">
                      {selectedInvoice.lineItems.map(item => (
                        <tr key={item.id}>
                          <td className="py-2.5 px-3 text-white font-medium">{item.description}</td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">{item.quantity}</td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">
                            ${item.unitPrice.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-white">
                            ${item.total.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Subtotals */}
                <div className="space-y-1.5 text-right font-mono text-xs pt-2">
                  <div className="flex justify-between text-slate-400">
                    <span>Subtotal</span>
                    <span>${selectedInvoice.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Marina Environmental Surcharge & Tax</span>
                    <span>${selectedInvoice.tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-base font-bold text-white pt-2 border-t border-slate-800">
                    <span>Total Due</span>
                    <span className="text-cyan-400">${selectedInvoice.total.toFixed(2)} USD</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                  <button
                    onClick={() => {
                      window.print();
                    }}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" /> Print Statement
                  </button>

                  {selectedInvoice.status !== 'paid' && (
                    <button
                      onClick={() => setShowPaymentModal(true)}
                      className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                    >
                      <CreditCard className="w-4 h-4" /> Record Payment
                    </button>
                  )}
                </div>

              </div>
            );
          })()}
        </Modal>
      )}

      {/* Modal: Record Payment */}
      {showPaymentModal && selectedInvoice && (
        <Modal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          title={`Process Payment for ${selectedInvoice.invoiceNumber}`}
          subtitle={`Amount to settle: $${selectedInvoice.total.toFixed(2)} USD`}
        >
          <form onSubmit={handleRecordPayment} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Payment Method</label>
              <select
                value={paymentMethodSelect}
                onChange={e => setPaymentMethodSelect(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="Visa Platinum on file (...4192)">Visa Platinum on file (...4192)</option>
                <option value="Amex Centurion (...8834)">Amex Centurion (...8834)</option>
                <option value="ACH Bank Direct Debit (Chase Private)">ACH Bank Direct Debit (Chase Private)</option>
                <option value="Dockmaster Terminal Card Swipe">Dockmaster Terminal Card Swipe</option>
                <option value="Bank Wire / Certified Check">Bank Wire / Certified Check</option>
              </select>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-slate-300 text-[11px] space-y-1">
              <div>• Folio balance will be zeroed immediately upon recording.</div>
              <div>• Automated receipt emailed to member account.</div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowPaymentModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-lg cursor-pointer"
              >
                Confirm Payment Receipt
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Modal: Create Folio Invoice */}
      {showNewInvoiceModal && (
        <Modal
          isOpen={showNewInvoiceModal}
          onClose={() => setShowNewInvoiceModal(false)}
          title="Create New Folio Invoice / Service Charge"
          subtitle="Generate itemized billing for slip leases, utilities, fuel, or work orders"
          maxWidth="max-w-3xl"
        >
          <form onSubmit={handleCreateInvoiceSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Select Member Account</label>
                <select
                  value={invMemberId}
                  onChange={e => setInvMemberId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-cyan-500"
                  required
                >
                  {members.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.fullName} ({m.memberTier.replace('_', ' ')})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Payment Due Date</label>
                <input
                  type="date"
                  value={invDueDate}
                  onChange={e => setInvDueDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                  required
                />
              </div>
            </div>

            {/* Line items builder */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-slate-300 font-medium">Itemized Line Items</label>
                <button
                  type="button"
                  onClick={handleAddLineItem}
                  className="text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
                >
                  + Add Line Item
                </button>
              </div>

              <div className="space-y-2">
                {lineItems.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 items-center">
                    <div className="col-span-5">
                      <input
                        type="text"
                        placeholder="Description (e.g. Electric utility)"
                        value={item.description}
                        onChange={e => handleUpdateLineItem(idx, 'description', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 text-white"
                        required
                      />
                    </div>
                    <div className="col-span-3">
                      <select
                        value={item.category}
                        onChange={e => handleUpdateLineItem(idx, 'category', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 text-slate-200"
                      >
                        <option value="slip_lease">Slip Lease</option>
                        <option value="electric_kwh">Electric Utility</option>
                        <option value="fuel">Marine Fuel</option>
                        <option value="service">Marine Service / Detailing</option>
                        <option value="transient">Transient Berthing</option>
                      </select>
                    </div>
                    <div className="col-span-2">
                      <input
                        type="number"
                        step="any"
                        placeholder="Qty"
                        value={item.quantity}
                        onChange={e => handleUpdateLineItem(idx, 'quantity', Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 font-mono text-white text-right"
                        required
                      />
                    </div>
                    <div className="col-span-2 flex items-center gap-2">
                      <input
                        type="number"
                        step="0.01"
                        placeholder="Rate"
                        value={item.unitPrice}
                        onChange={e => handleUpdateLineItem(idx, 'unitPrice', Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 font-mono text-white text-right"
                        required
                      />
                      {lineItems.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveLineItem(idx)}
                          className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-right font-mono text-sm font-bold text-white pt-2">
              Invoice Total: $
              {lineItems
                .reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)
                .toFixed(2)}{' '}
              USD
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowNewInvoiceModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer shadow-sm"
              >
                Issue Invoice to Folio
              </button>
            </div>
          </form>
        </Modal>
      )}

    </div>
  );
};
