import React, { useState } from 'react';
import { useMarina } from '../context/MarinaContext';
import { HarborLog, HarborEntryType } from '../types/marina';
import { Modal } from './Modal';
import { 
  Radio, 
  Fuel, 
  Waves, 
  Wind, 
  Thermometer, 
  Compass, 
  AlertTriangle, 
  ShieldAlert, 
  Plus, 
  Clock, 
  Droplet, 
  Anchor, 
  CheckCircle2, 
  Activity, 
  Navigation
} from 'lucide-react';

export const HarborMasterView: React.FC = () => {
  const { 
    logs, 
    conditions, 
    fuelInventory, 
    members, 
    slips, 
    addHarborLog, 
    dispenseFuel, 
    setHarborFlag 
  } = useMarina();

  // Modals
  const [showLogModal, setShowLogModal] = useState<boolean>(false);
  const [showFuelModal, setShowFuelModal] = useState<boolean>(false);

  // New Log Event Form
  const [logType, setLogType] = useState<HarborEntryType>('arrival');
  const [logMsg, setLogMsg] = useState<string>('');
  const [logSeverity, setLogSeverity] = useState<'nominal' | 'advisory' | 'alert'>('nominal');
  const [logVhf, setLogVhf] = useState<string>('Ch 68');

  // Fuel Dispenser Form
  const [fuelType, setFuelType] = useState<'diesel' | 'rec90_gas'>('diesel');
  const [fuelGallons, setFuelGallons] = useState<number>(100);
  const [fuelRecipient, setFuelRecipient] = useState<string>('Slip D-01 (San Juan Belle)');
  const [fuelMemberId, setFuelMemberId] = useState<string>(members[7]?.id || members[0]?.id || '');

  // Log filter
  const [entryTypeFilter, setEntryTypeFilter] = useState<string>('all');

  const filteredLogs = logs.filter(l => {
    if (entryTypeFilter !== 'all' && l.entryType !== entryTypeFilter) return false;
    return true;
  });

  const handleAddLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logMsg.trim()) return;

    addHarborLog(logType, logMsg, logSeverity, logVhf);
    setLogMsg('');
    setShowLogModal(false);
  };

  const handleDispenseFuelSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (fuelGallons <= 0) return;

    dispenseFuel(fuelType, fuelGallons, fuelRecipient, fuelMemberId || undefined);
    setShowFuelModal(false);
  };

  const getLogTypeBadge = (type: HarborEntryType) => {
    switch (type) {
      case 'arrival':
        return { label: 'Arrival', color: 'text-cyan-400' };
      case 'departure':
        return { label: 'Departure', color: 'text-emerald-400' };
      case 'weather':
        return { label: 'Weather', color: 'text-blue-400' };
      case 'maintenance':
        return { label: 'Maintenance', color: 'text-amber-400' };
      case 'security':
        return { label: 'Security', color: 'text-purple-400' };
      case 'pumpout':
        return { label: 'Pump-Out', color: 'text-teal-400' };
      case 'fuel_dock':
        return { label: 'Fuel Dock', color: 'text-amber-300' };
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Live Marine Environment & Harbor Station */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <Radio className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="text-sm font-semibold text-white tracking-tight">
                Harbor Master Marine Weather & Tidal Station
              </h3>
              <p className="text-xs text-slate-400">Station ID: NAUTICA-MET-01 · Real-time sensors</p>
            </div>
          </div>

          {/* Harbor Flag Advisory Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Harbor Flag:</span>
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-1 text-xs">
              <button
                onClick={() => setHarborFlag('green')}
                className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                  conditions.harborFlag === 'green'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Clear Waters
              </button>
              <button
                onClick={() => setHarborFlag('amber')}
                className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                  conditions.harborFlag === 'amber'
                    ? 'bg-amber-950 text-amber-300 border border-amber-800'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Small Craft Advisory
              </button>
              <button
                onClick={() => setHarborFlag('red')}
                className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                  conditions.harborFlag === 'red'
                    ? 'bg-rose-950 text-rose-300 border border-rose-800'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Gale Warning
              </button>
            </div>
          </div>
        </div>

        {/* Environmental Indicators */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          
          {/* Wind */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3.5 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-400">
              <Wind className="w-3.5 h-3.5 text-cyan-400" />
              <span>Surface Wind</span>
            </div>
            <div className="text-xl font-bold font-mono text-white tabular-nums">
              {conditions.windSpeedKts} kts
            </div>
            <div className="text-slate-400 text-[11px] font-mono">
              Direction: {conditions.windDirection} (Gusts {conditions.windGustsKts} kts)
            </div>
          </div>

          {/* Tides */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3.5 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-400">
              <Waves className="w-3.5 h-3.5 text-cyan-400" />
              <span>Tidal Cycle</span>
            </div>
            <div className="text-xl font-bold font-mono text-white tabular-nums">
              {conditions.tideHeightFt}ft MLLW
            </div>
            <div className="text-slate-400 text-[11px] font-mono">
              {conditions.tideState} · Next {conditions.nextTideType}: {conditions.nextTideTime} ({conditions.nextTideHeightFt}ft)
            </div>
          </div>

          {/* Barometer */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3.5 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-400">
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              <span>Barometric Pressure</span>
            </div>
            <div className="text-xl font-bold font-mono text-white tabular-nums">
              {conditions.barometricPressureHpa} hPa
            </div>
            <div className="text-slate-400 text-[11px] font-mono capitalize">
              Trend: {conditions.pressureTrend} · Water Temp: {conditions.waterTempF}°F
            </div>
          </div>

          {/* VHF Monitoring */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3.5 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-400">
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              <span>VHF Radio Watch</span>
            </div>
            <div className="text-sm font-bold font-mono text-cyan-400 mt-1">
              Ch 16 / Ch 68 Active
            </div>
            <div className="text-slate-400 text-[11px]">
              Harbor hail frequency: Ch 09
            </div>
          </div>

        </div>
      </div>

      {/* Fuel Dock Operations Station */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <Fuel className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-sm font-semibold text-white tracking-tight">
                Fuel Dock Dispenser & Underground Tank Inventory
              </h3>
              <p className="text-xs text-slate-400">Pier D Fuel Float · Certified ValvTect Marine Additives</p>
            </div>
          </div>

          <button
            onClick={() => setShowFuelModal(true)}
            className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" /> Dispense Fuel to Vessel
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Diesel Tank */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  ValvTect Marine Diesel #2
                </span>
                <div className="text-xs text-slate-400 mt-0.5">Cetane improved, anti-microbial biocide treated</div>
              </div>
              <span className="text-sm font-bold font-mono text-cyan-400">
                ${fuelInventory.dieselPricePerGal.toFixed(2)} / gal
              </span>
            </div>

            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Tank Volume</span>
                <span>{fuelInventory.dieselGallons.toLocaleString()} / {fuelInventory.dieselCapacity.toLocaleString()} gal</span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-cyan-500 h-full rounded-full transition-all"
                  style={{ width: `${(fuelInventory.dieselGallons / fuelInventory.dieselCapacity) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* Gasoline Tank */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Rec-90 Non-Ethanol Marine Gasoline
                </span>
                <div className="text-xs text-slate-400 mt-0.5">Ethanol-free 90 Octane for high-performance outboards</div>
              </div>
              <span className="text-sm font-bold font-mono text-amber-400">
                ${fuelInventory.gasPricePerGal.toFixed(2)} / gal
              </span>
            </div>

            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Tank Volume</span>
                <span>{fuelInventory.gasGallons.toLocaleString()} / {fuelInventory.gasCapacity.toLocaleString()} gal</span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-amber-500 h-full rounded-full transition-all"
                  style={{ width: `${(fuelInventory.gasGallons / fuelInventory.gasCapacity) * 100}%` }}
                />
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Harbor Master Chronological Log */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white tracking-tight">
              Harbor Master Daily Operations & Radio Log
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 overflow-x-auto text-xs">
              {['all', 'arrival', 'departure', 'weather', 'security', 'fuel_dock'].map(t => (
                <button
                  key={t}
                  onClick={() => setEntryTypeFilter(t)}
                  className={`px-2.5 py-1 rounded capitalize transition-colors cursor-pointer ${
                    entryTypeFilter === t
                      ? 'bg-slate-800 text-cyan-400 font-semibold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t.replace('_', ' ')}
                </button>
              ))}
            </div>

            <button
              onClick={() => setShowLogModal(true)}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0"
            >
              + Log Event
            </button>
          </div>
        </div>

        {/* Log stream */}
        <div className="space-y-2.5">
          {filteredLogs.map(log => {
            const badge = getLogTypeBadge(log.entryType);

            return (
              <div 
                key={log.id} 
                className="p-3 bg-slate-950 border border-slate-800/80 rounded-lg text-xs flex flex-col sm:flex-row sm:items-start justify-between gap-2"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-400 text-[11px]">{log.timestamp}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className={`font-semibold capitalize ${badge.color}`}>{badge.label}</span>
                    {log.vhfChannel && (
                      <>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="text-slate-400 font-mono text-[11px]">{log.vhfChannel}</span>
                      </>
                    )}
                  </div>
                  <p className="text-slate-200 leading-relaxed">{log.message}</p>
                </div>

                <div className="text-slate-400 text-[11px] shrink-0 sm:text-right font-mono">
                  {log.recordedBy}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal: New Log Event */}
      {showLogModal && (
        <Modal
          isOpen={showLogModal}
          onClose={() => setShowLogModal(false)}
          title="Record Harbor Master Log Entry"
          subtitle="Document operational arrivals, transient hails, maintenance, or security checks"
        >
          <form onSubmit={handleAddLogSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Event Category</label>
                <select
                  value={logType}
                  onChange={e => setLogType(e.target.value as HarborEntryType)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                >
                  <option value="arrival">Vessel Arrival / Docking</option>
                  <option value="departure">Vessel Departure</option>
                  <option value="weather">Weather & Marine Advisory</option>
                  <option value="maintenance">Basin / Dock Maintenance</option>
                  <option value="security">Perimeter & Security Patrol</option>
                  <option value="pumpout">Pump-Out Station Operation</option>
                  <option value="fuel_dock">Fuel Float Log</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">VHF Channel Monitored</label>
                <input
                  type="text"
                  value={logVhf}
                  onChange={e => setLogVhf(e.target.value)}
                  placeholder="e.g. Ch 16, Ch 68, Ch 09"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Log Message Details</label>
              <textarea
                rows={3}
                value={logMsg}
                onChange={e => setLogMsg(e.target.value)}
                placeholder="Enter detailed observation, vessel registration, or action taken..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
                required
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowLogModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer"
              >
                Record in Official Log
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Modal: Dispense Fuel */}
      {showFuelModal && (
        <Modal
          isOpen={showFuelModal}
          onClose={() => setShowFuelModal(false)}
          title="Dispense Marine Fuel"
          subtitle="Fuel float flow meter log and automated folio charging"
        >
          <form onSubmit={handleDispenseFuelSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Fuel Type</label>
                <select
                  value={fuelType}
                  onChange={e => setFuelType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                >
                  <option value="diesel">ValvTect Marine Diesel (${fuelInventory.dieselPricePerGal}/gal)</option>
                  <option value="rec90_gas">Rec-90 Non-Ethanol Gas (${fuelInventory.gasPricePerGal}/gal)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Dispensed Quantity (Gallons)</label>
                <input
                  type="number"
                  step="any"
                  min="1"
                  value={fuelGallons}
                  onChange={e => setFuelGallons(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono text-white text-base"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Vessel Name / Berth Slip</label>
              <input
                type="text"
                value={fuelRecipient}
                onChange={e => setFuelRecipient(e.target.value)}
                placeholder="e.g. Slip A-01 (Valkyrie II)"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Charge to Member Folio</label>
              <select
                value={fuelMemberId}
                onChange={e => setFuelMemberId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
              >
                <option value="">No Folio (Direct Dockmaster Terminal Payment)</option>
                {members.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.fullName} ({m.memberTier.replace('_', ' ')})
                  </option>
                ))}
              </select>
            </div>

            <div className="p-3 bg-cyan-950/20 border border-cyan-800/40 rounded-lg text-slate-200 text-xs">
              <span className="text-slate-400 block text-[11px]">Total Transaction Amount:</span>
              <span className="text-base font-bold font-mono text-cyan-300">
                ${(fuelGallons * (fuelType === 'diesel' ? fuelInventory.dieselPricePerGal : fuelInventory.gasPricePerGal)).toFixed(2)} USD
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowFuelModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded-lg cursor-pointer"
              >
                Confirm Fuel Delivery
              </button>
            </div>
          </form>
        </Modal>
      )}

    </div>
  );
};
