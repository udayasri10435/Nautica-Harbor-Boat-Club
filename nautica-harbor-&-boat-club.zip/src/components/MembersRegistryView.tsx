import React, { useState } from 'react';
import { useMarina } from '../context/MarinaContext';
import { Member, Vessel, MemberTier, VesselType } from '../types/marina';
import { Modal } from './Modal';
import { 
  Users, 
  Search, 
  Filter, 
  Shield, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  CreditCard, 
  Ship, 
  FileText, 
  Phone, 
  Mail, 
  Radio, 
  Calendar,
  Anchor
} from 'lucide-react';

export const MembersRegistryView: React.FC = () => {
  const { 
    members, 
    vessels, 
    slips, 
    addMember, 
    updateMemberInsurance 
  } = useMarina();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [insuranceAlertFilter, setInsuranceAlertFilter] = useState<boolean>(false);

  // Modals
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [showAddMemberModal, setShowAddMemberModal] = useState<boolean>(false);
  const [showInsuranceModal, setShowInsuranceModal] = useState<boolean>(false);
  const [selectedVesselForInsurance, setSelectedVesselForInsurance] = useState<Vessel | null>(null);

  // New Member Form
  const [newName, setNewName] = useState<string>('');
  const [newEmail, setNewEmail] = useState<string>('');
  const [newPhone, setNewPhone] = useState<string>('');
  const [newEmergency, setNewEmergency] = useState<string>('');
  const [newTier, setNewTier] = useState<MemberTier>('slip_holder');
  const [newLicence, setNewLicence] = useState<string>('WA-BOATER-');
  const [newVhf, setNewVhf] = useState<string>('');

  // Attached Vessel
  const [hasVessel, setHasVessel] = useState<boolean>(true);
  const [vesName, setVesName] = useState<string>('');
  const [vesMakeModel, setVesMakeModel] = useState<string>('');
  const [vesYear, setVesYear] = useState<number>(2022);
  const [vesLoa, setVesLoa] = useState<number>(36);
  const [vesBeam, setVesBeam] = useState<number>(12);
  const [vesDraft, setVesDraft] = useState<number>(3.8);
  const [vesReg, setVesReg] = useState<string>('WN-');
  const [vesType, setVesType] = useState<VesselType>('Motor Yacht');
  const [vesInsuranceCarrier, setVesInsuranceCarrier] = useState<string>('Travelers Marine');
  const [vesInsurancePolicy, setVesInsurancePolicy] = useState<string>('POL-');
  const [vesInsuranceExpiry, setVesInsuranceExpiry] = useState<string>('2027-08-31');

  // Insurance renewal form
  const [renewPolicyNo, setRenewPolicyNo] = useState<string>('');
  const [renewCarrier, setRenewCarrier] = useState<string>('');
  const [renewExpiry, setRenewExpiry] = useState<string>('');

  // Insurance check helper
  const isExpiringSoon = (expiryDate: string) => {
    const expiry = new Date(expiryDate).getTime();
    const now = new Date('2026-09-29').getTime();
    const daysLeft = (expiry - now) / (1000 * 3600 * 24);
    return daysLeft <= 30;
  };

  const filteredMembers = members.filter(m => {
    if (tierFilter !== 'all' && m.memberTier !== tierFilter) return false;

    const memberVessels = vessels.filter(v => v.ownerMemberId === m.id);
    if (insuranceAlertFilter) {
      const hasExpiring = memberVessels.some(v => isExpiringSoon(v.insuranceExpiry));
      if (!hasExpiring) return false;
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = m.fullName.toLowerCase().includes(q);
      const matchEmail = m.email.toLowerCase().includes(q);
      const matchVessel = memberVessels.some(v => v.name.toLowerCase().includes(q) || v.registrationNo.toLowerCase().includes(q));
      if (!matchName && !matchEmail && !matchVessel) return false;
    }

    return true;
  });

  const handleCreateMember = (e: React.FormEvent) => {
    e.preventDefault();
    const memberData = {
      fullName: newName,
      email: newEmail,
      phone: newPhone,
      emergencyContact: newEmergency,
      memberTier: newTier,
      boatLicenceNo: newLicence,
      vhfCallsign: newVhf || undefined,
      paymentMethodOnFile: { type: 'credit_card' as const, last4: '4820', brand: 'Visa' },
      remainingBookingPoints: newTier === 'commodore_club' ? 6 : newTier === 'captain_club' ? 2 : 4
    };

    const vesselData = hasVessel && vesName ? {
      name: vesName,
      makeModel: vesMakeModel,
      year: Number(vesYear),
      loaFt: Number(vesLoa),
      beamFt: Number(vesBeam),
      draftFt: Number(vesDraft),
      registrationNo: vesReg,
      hullColor: 'White & Navy',
      vesselType: vesType,
      insuranceCarrier: vesInsuranceCarrier,
      insurancePolicyNo: vesInsurancePolicy,
      insuranceExpiry: vesInsuranceExpiry,
      insuranceVerified: true
    } : undefined;

    addMember(memberData, vesselData);
    setShowAddMemberModal(false);

    // Reset fields
    setNewName('');
    setNewEmail('');
    setNewPhone('');
  };

  const handleRenewInsurance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVesselForInsurance) return;
    updateMemberInsurance(selectedVesselForInsurance.id, renewPolicyNo, renewCarrier, renewExpiry);
    setShowInsuranceModal(false);
  };

  const getTierLabel = (tier: MemberTier) => {
    switch (tier) {
      case 'slip_holder':
        return 'Slip Holder';
      case 'commodore_club':
        return 'Boat Club Commodore';
      case 'captain_club':
        return 'Boat Club Captain';
      case 'yacht_social':
        return 'Yacht Club Social';
      case 'transient_guest':
        return 'Transient Guest';
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner and Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Total Registered Members</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">{members.length}</span>
            <span className="text-xs text-slate-400 font-mono">Holders & Club</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Active club community
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Registered Vessels</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-cyan-400">{vessels.length}</span>
            <span className="text-xs text-slate-400">Private craft</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            All USCG / WA state verified
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Insurance Audits</div>
          <div className="flex items-baseline gap-2 mt-1">
            {vessels.filter(v => isExpiringSoon(v.insuranceExpiry)).length > 0 ? (
              <span className="text-2xl font-bold font-mono tabular-nums text-amber-400">
                {vessels.filter(v => isExpiringSoon(v.insuranceExpiry)).length}
              </span>
            ) : (
              <span className="text-2xl font-bold font-mono tabular-nums text-emerald-400">100%</span>
            )}
            <span className="text-xs text-slate-400">Expiring &lt;30 days</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Minimum $500k liability compliance
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="text-xs text-slate-400">Member Onboarding</div>
          <button
            onClick={() => setShowAddMemberModal(true)}
            className="w-full mt-2 py-2 px-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" /> Add Member & Vessel
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search member name, vessel, email, or licence..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-100 rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto">
            {['all', 'slip_holder', 'commodore_club', 'captain_club', 'transient_guest'].map(t => (
              <button
                key={t}
                onClick={() => setTierFilter(t)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                  tierFilter === t
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
                }`}
              >
                {t === 'all' ? 'All Tiers' : t.replace('_', ' ')}
              </button>
            ))}

            {/* Insurance alert toggle */}
            <button
              onClick={() => setInsuranceAlertFilter(!insuranceAlertFilter)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
                insuranceAlertFilter
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Insurance Alerts
            </button>
          </div>
        </div>
      </div>

      {/* Members Directory Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950 text-slate-400 font-semibold">
                <th className="py-3 px-4">Member Name</th>
                <th className="py-3 px-4">Membership Tier</th>
                <th className="py-3 px-4">Assigned Slip</th>
                <th className="py-3 px-4">Registered Vessel</th>
                <th className="py-3 px-4">Insurance Compliance</th>
                <th className="py-3 px-4">Club Tokens</th>
                <th className="py-3 px-4 text-right">Folio Balance</th>
                <th className="py-3 px-4 text-center">Profile</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredMembers.map(member => {
                const memberVessels = vessels.filter(v => v.ownerMemberId === member.id);
                const assignedSlip = slips.find(s => s.id === member.assignedSlipId);
                const primaryVessel = memberVessels[0];
                const hasInsuranceWarning = primaryVessel && isExpiringSoon(primaryVessel.insuranceExpiry);

                return (
                  <tr
                    key={member.id}
                    onClick={() => setSelectedMember(member)}
                    className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-cyan-400 text-xs shrink-0">
                          {member.avatarInitials}
                        </div>
                        <div>
                          <div className="font-semibold text-white">{member.fullName}</div>
                          <div className="text-slate-400 text-[11px] font-mono">{member.phone}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-200 block">
                        {getTierLabel(member.memberTier)}
                      </span>
                      <span className="text-slate-400 text-[11px]">Since {member.memberSince}</span>
                    </td>

                    <td className="py-3 px-4">
                      {assignedSlip ? (
                        <div className="font-mono">
                          <span className="font-bold text-cyan-300">{assignedSlip.code}</span>
                          <span className="text-slate-400 text-[11px] block">{assignedSlip.pier.split(' (')[0]}</span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">No Berth</span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      {primaryVessel ? (
                        <div>
                          <span className="font-semibold text-white flex items-center gap-1.5">
                            <Ship className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                            {primaryVessel.name}
                          </span>
                          <span className="text-slate-400 text-[11px] font-mono">
                            {primaryVessel.loaFt}ft {primaryVessel.makeModel}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">No vessel registered</span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      {primaryVessel ? (
                        hasInsuranceWarning ? (
                          <div className="text-amber-400 flex items-center gap-1.5 font-medium">
                            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                            <span>Expiring: {primaryVessel.insuranceExpiry}</span>
                          </div>
                        ) : (
                          <div className="text-emerald-400 flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                            <span>Active: {primaryVessel.insuranceCarrier}</span>
                          </div>
                        )
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>

                    <td className="py-3 px-4 font-mono tabular-nums text-slate-200">
                      {member.remainingBookingPoints > 0 ? (
                        <span className="text-cyan-400 font-semibold">{member.remainingBookingPoints} tokens</span>
                      ) : (
                        <span className="text-slate-400">0</span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {member.balanceDue > 0 ? (
                        <span className="text-amber-400 font-semibold">${member.balanceDue.toFixed(2)}</span>
                      ) : (
                        <span className="text-emerald-400">$0.00 (Current)</span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedMember(member);
                        }}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded text-xs cursor-pointer font-medium"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Member Profile Drawer */}
      {selectedMember && (
        <Modal
          isOpen={!!selectedMember}
          onClose={() => setSelectedMember(null)}
          title={`Member Profile: ${selectedMember.fullName}`}
          subtitle={`${getTierLabel(selectedMember.memberTier)} · Member since ${selectedMember.memberSince}`}
        >
          <div className="space-y-5 text-xs">
            
            {/* Quick Contact & Credentials Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950 p-4 rounded-lg border border-slate-800">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-slate-300">
                  <Mail className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{selectedMember.email}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Phone className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="font-mono">{selectedMember.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                  <span>Emergency: {selectedMember.emergencyContact}</span>
                </div>
              </div>

              <div className="space-y-2 border-t md:border-t-0 md:border-l border-slate-800 pt-2 md:pt-0 md:pl-4">
                <div className="flex items-center gap-2 text-slate-300">
                  <Shield className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-mono">License: {selectedMember.boatLicenceNo}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Radio className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="font-mono">VHF Callsign: {selectedMember.vhfCallsign || 'None registered'}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                  <CreditCard className="w-3.5 h-3.5 text-slate-400" />
                  <span>Card on File: {selectedMember.paymentMethodOnFile.brand} (ending in {selectedMember.paymentMethodOnFile.last4})</span>
                </div>
              </div>
            </div>

            {/* Registered Vessels Section */}
            <div className="border border-slate-800 rounded-lg p-4 bg-slate-900/50 space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Registered Private Craft
              </h4>

              {vessels.filter(v => v.ownerMemberId === selectedMember.id).length === 0 ? (
                <div className="text-slate-400 text-xs italic py-2">
                  No vessels registered to this member account.
                </div>
              ) : (
                <div className="space-y-3">
                  {vessels
                    .filter(v => v.ownerMemberId === selectedMember.id)
                    .map(v => (
                      <div key={v.id} className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="text-sm font-bold text-white flex items-center gap-2">
                              <Ship className="w-4 h-4 text-cyan-400" />
                              {v.name}
                            </div>
                            <div className="text-slate-400 text-xs">
                              {v.year} {v.makeModel} ({v.vesselType})
                            </div>
                          </div>

                          <button
                            onClick={() => {
                              setSelectedVesselForInsurance(v);
                              setRenewPolicyNo(v.insurancePolicyNo);
                              setRenewCarrier(v.insuranceCarrier);
                              setRenewExpiry(v.insuranceExpiry);
                              setShowInsuranceModal(true);
                            }}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded text-xs cursor-pointer"
                          >
                            Update Insurance
                          </button>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono tabular-nums text-slate-300 pt-1">
                          <div>LOA: {v.loaFt}ft</div>
                          <div>Beam: {v.beamFt}ft</div>
                          <div>Draft: {v.draftFt}ft</div>
                          <div>Reg: {v.registrationNo}</div>
                        </div>

                        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                          <span className="text-slate-400">
                            Policy: {v.insuranceCarrier} #{v.insurancePolicyNo}
                          </span>
                          <span className={isExpiringSoon(v.insuranceExpiry) ? 'text-amber-400 font-semibold' : 'text-emerald-400'}>
                            Expires: {v.insuranceExpiry}
                          </span>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>

            {/* Berth Assignment info */}
            <div className="border border-slate-800 rounded-lg p-4 bg-slate-900/50 flex items-center justify-between">
              <div>
                <span className="text-slate-400 block">Assigned Marina Slip</span>
                {selectedMember.assignedSlipId ? (
                  (() => {
                    const slip = slips.find(s => s.id === selectedMember.assignedSlipId);
                    return (
                      <div className="text-white font-bold text-sm font-mono mt-0.5">
                        {slip?.code} ({slip?.pier}) · ${slip?.monthlyRate}/mo
                      </div>
                    );
                  })()
                ) : (
                  <span className="text-slate-400 italic">No permanent slip assigned</span>
                )}
              </div>

              <div>
                <span className="text-slate-400 block text-right">Account Balance</span>
                <span className="text-sm font-mono font-bold text-cyan-400 block text-right mt-0.5">
                  ${selectedMember.balanceDue.toFixed(2)}
                </span>
              </div>
            </div>

          </div>
        </Modal>
      )}

      {/* Modal: Add Member & Vessel */}
      {showAddMemberModal && (
        <Modal
          isOpen={showAddMemberModal}
          onClose={() => setShowAddMemberModal(false)}
          title="Onboard New Marina & Boat Club Member"
          subtitle="Create member folio account and register initial vessel credentials"
        >
          <form onSubmit={handleCreateMember} className="space-y-4 text-xs">
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Full Legal Name</label>
                <input
                  type="text"
                  placeholder="e.g. Captain Jonathan Ross"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Membership Tier</label>
                <select
                  value={newTier}
                  onChange={e => setNewTier(e.target.value as MemberTier)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
                >
                  <option value="slip_holder">Slip Holder (Marina Berth)</option>
                  <option value="commodore_club">Boat Club Commodore (6 Tokens)</option>
                  <option value="captain_club">Boat Club Captain (2 Tokens)</option>
                  <option value="yacht_social">Yacht Club Social</option>
                  <option value="transient_guest">Transient Visitor</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="jross@example.com"
                  value={newEmail}
                  onChange={e => setNewEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Phone Number</label>
                <input
                  type="text"
                  placeholder="(206) 555-0199"
                  value={newPhone}
                  onChange={e => setNewPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Boater Education / License #</label>
                <input
                  type="text"
                  placeholder="WA-BOATER-19402"
                  value={newLicence}
                  onChange={e => setNewLicence(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">VHF Radio Callsign (Optional)</label>
                <input
                  type="text"
                  placeholder="WKB-1029"
                  value={newVhf}
                  onChange={e => setNewVhf(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* Optional Attached Vessel Registration */}
            <div className="border border-slate-800 rounded-lg p-3.5 bg-slate-950 space-y-3">
              <label className="flex items-center gap-2 text-white font-medium cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasVessel}
                  onChange={e => setHasVessel(e.target.checked)}
                  className="rounded border-slate-700 accent-cyan-500"
                />
                <span>Register Private Vessel at this time</span>
              </label>

              {hasVessel && (
                <div className="space-y-3 pt-2">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1">Vessel Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Sea Spirit"
                        value={vesName}
                        onChange={e => setVesName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 text-white"
                        required={hasVessel}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Make & Model</label>
                      <input
                        type="text"
                        placeholder="e.g. Jeanneau Sun Odyssey 410"
                        value={vesMakeModel}
                        onChange={e => setVesMakeModel(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 text-white"
                        required={hasVessel}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1">LOA Length (ft)</label>
                      <input
                        type="number"
                        value={vesLoa}
                        onChange={e => setVesLoa(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 font-mono text-white"
                        required={hasVessel}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Beam Width (ft)</label>
                      <input
                        type="number"
                        value={vesBeam}
                        onChange={e => setVesBeam(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 font-mono text-white"
                        required={hasVessel}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Draft Depth (ft)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={vesDraft}
                        onChange={e => setVesDraft(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 font-mono text-white"
                        required={hasVessel}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1">Insurance Carrier</label>
                      <input
                        type="text"
                        value={vesInsuranceCarrier}
                        onChange={e => setVesInsuranceCarrier(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 text-white"
                        required={hasVessel}
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Insurance Policy Expiry</label>
                      <input
                        type="date"
                        value={vesInsuranceExpiry}
                        onChange={e => setVesInsuranceExpiry(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded p-1.5 font-mono text-white"
                        required={hasVessel}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddMemberModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer shadow-sm"
              >
                Complete Onboarding
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Modal: Update Insurance */}
      {showInsuranceModal && selectedVesselForInsurance && (
        <Modal
          isOpen={showInsuranceModal}
          onClose={() => setShowInsuranceModal(false)}
          title={`Update Marine Insurance: ${selectedVesselForInsurance.name}`}
          subtitle="Mandatory $500,000 protection & indemnity liability verification"
        >
          <form onSubmit={handleRenewInsurance} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Insurance Underwriter / Carrier</label>
              <input
                type="text"
                value={renewCarrier}
                onChange={e => setRenewCarrier(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Policy Number</label>
              <input
                type="text"
                value={renewPolicyNo}
                onChange={e => setRenewPolicyNo(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono text-white"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">New Expiration Date</label>
              <input
                type="date"
                value={renewExpiry}
                onChange={e => setRenewExpiry(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono text-white"
                required
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowInsuranceModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer"
              >
                Save Insurance Verification
              </button>
            </div>
          </form>
        </Modal>
      )}

    </div>
  );
};
