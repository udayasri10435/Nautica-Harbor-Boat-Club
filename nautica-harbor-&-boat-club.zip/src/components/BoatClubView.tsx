import React, { useState } from 'react';
import { useMarina } from '../context/MarinaContext';
import { ClubBoat, Reservation, TimeSlot, FloatPlan, BoatClubStatus } from '../types/marina';
import { Modal } from './Modal';
import { 
  Ship, 
  Calendar, 
  Users, 
  Gauge, 
  Fuel, 
  Compass, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Play, 
  RotateCcw, 
  MapPin, 
  ShieldCheck, 
  Plus, 
  Anchor
} from 'lucide-react';

export const BoatClubView: React.FC = () => {
  const { 
    boats, 
    reservations, 
    members, 
    fuelInventory, 
    createReservation, 
    dispatchReservation, 
    checkinReservation, 
    cancelReservation 
  } = useMarina();

  // Active sub-tab
  const [activeTab, setActiveTab] = useState<'fleet' | 'trips'>('fleet');

  // Modals
  const [showBookingModal, setShowBookingModal] = useState<boolean>(false);
  const [showDispatchModal, setShowDispatchModal] = useState<boolean>(false);
  const [showCheckinModal, setShowCheckinModal] = useState<boolean>(false);
  const [selectedBoatForBooking, setSelectedBoatForBooking] = useState<ClubBoat | null>(null);
  const [selectedResForAction, setSelectedResForAction] = useState<Reservation | null>(null);

  // Booking Form State
  const [bookMemberId, setBookMemberId] = useState<string>(members[2]?.id || members[0]?.id || '');
  const [bookDate, setBookDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [bookSlot, setBookSlot] = useState<TimeSlot>('morning');
  const [destination, setDestination] = useState<string>('Pelican Bay & Horseshoe Cove');
  const [crewCount, setCrewCount] = useState<number>(4);
  const [shoreContact, setShoreContact] = useState<string>('Evelyn Vance (206) 555-0183');
  const [safetyBriefing, setSafetyBriefing] = useState<boolean>(true);
  const [lifeJackets, setLifeJackets] = useState<number>(6);
  const [floatNotes, setFloatNotes] = useState<string>('Day cruise with light fishing near Point No Point.');

  // Dispatch & Checkin Form States
  const [startHours, setStartHours] = useState<number>(0);
  const [returnHours, setReturnHours] = useState<number>(0);
  const [fuelBurned, setFuelBurned] = useState<number>(12);
  const [checkinNotes, setCheckinNotes] = useState<string>('Vessel returned clean. Safety gear and lines secured.');

  const handleOpenBooking = (boat?: ClubBoat) => {
    if (boat) {
      setSelectedBoatForBooking(boat);
    } else {
      setSelectedBoatForBooking(boats[0]);
    }
    setShowBookingModal(true);
  };

  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBoatForBooking || !bookMemberId) return;

    const floatPlan: FloatPlan = {
      destination,
      crewCount,
      shoreContactName: shoreContact.split(' (')[0],
      shoreContactPhone: shoreContact.includes('(') ? shoreContact.slice(shoreContact.indexOf('(')) : '(206) 555-0100',
      safetyBriefingConfirmed: safetyBriefing,
      lifeJacketsCount: lifeJackets,
      floatPlanNotes: floatNotes
    };

    createReservation(
      selectedBoatForBooking.id,
      bookMemberId,
      bookDate,
      bookSlot,
      floatPlan
    );

    setShowBookingModal(false);
    setActiveTab('trips');
  };

  const handleStartDispatch = (res: Reservation) => {
    setSelectedResForAction(res);
    const boat = boats.find(b => b.id === res.boatId);
    setStartHours(boat?.engineHours || 100);
    setShowDispatchModal(true);
  };

  const handleExecuteDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedResForAction) return;
    dispatchReservation(selectedResForAction.id, Number(startHours));
    setShowDispatchModal(false);
  };

  const handleStartCheckin = (res: Reservation) => {
    setSelectedResForAction(res);
    const boat = boats.find(b => b.id === res.boatId);
    setReturnHours(Number(((boat?.engineHours || 100) + 3.2).toFixed(1)));
    setFuelBurned(14.5);
    setShowCheckinModal(true);
  };

  const handleExecuteCheckin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedResForAction) return;
    checkinReservation(selectedResForAction.id, Number(returnHours), Number(fuelBurned), checkinNotes);
    setShowCheckinModal(false);
  };

  const getBoatStatusStyle = (st: BoatClubStatus) => {
    switch (st) {
      case 'available':
        return { label: 'Ready at Berth', dot: 'bg-emerald-400', badge: 'text-emerald-300' };
      case 'on_water':
        return { label: 'On Water (Underway)', dot: 'bg-cyan-400', badge: 'text-cyan-300' };
      case 'reserved':
        return { label: 'Reserved Today', dot: 'bg-amber-400', badge: 'text-amber-300' };
      case 'maintenance':
        return { label: 'Under Maintenance', dot: 'bg-rose-400', badge: 'text-rose-300' };
    }
  };

  const activeOnWaterTrips = reservations.filter(r => r.status === 'dispatched');
  const upcomingReservations = reservations.filter(r => r.status === 'confirmed');
  const pastTrips = reservations.filter(r => r.status === 'completed' || r.status === 'cancelled');

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Club Fleet Size</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">{boats.length}</span>
            <span className="text-xs text-slate-400">Turnkey vessels</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Center Consoles, Cruisers & Tritoon
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Active On-Water</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-cyan-400">
              {activeOnWaterTrips.length}
            </span>
            <span className="text-xs text-slate-400">Vessels dispatched</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            VHF Ch 16 / Ch 68 monitor active
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Today's Bookings</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-emerald-400">
              {upcomingReservations.length + activeOnWaterTrips.length}
            </span>
            <span className="text-xs text-slate-400">Float plans</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            All safety inspections logged
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="text-xs text-slate-400">Member Reservation Action</div>
          <button
            onClick={() => handleOpenBooking()}
            className="w-full mt-2 py-2 px-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" /> Book Club Vessel
          </button>
        </div>
      </div>

      {/* Segmented view controls */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('fleet')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'fleet'
                ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Managed Fleet Roster ({boats.length})
          </button>
          <button
            onClick={() => setActiveTab('trips')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === 'trips'
                ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Dispatch & Float Plans
            {activeOnWaterTrips.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            )}
          </button>
        </div>

        <button
          onClick={() => handleOpenBooking()}
          className="text-xs text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
        >
          + New Float Plan Reservation →
        </button>
      </div>

      {/* Tab 1: Fleet Roster Cards */}
      {activeTab === 'fleet' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {boats.map(boat => {
            const st = getBoatStatusStyle(boat.status);

            return (
              <div 
                key={boat.id}
                className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden hover:border-slate-700 transition-all flex flex-col justify-between"
              >
                {/* Visual Vessel Header Card */}
                <div className="p-5 pb-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-base font-bold text-white flex items-center gap-2">
                        <Ship className="w-4 h-4 text-cyan-400" />
                        {boat.name}
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        {boat.year} {boat.model}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs">
                      <span className={`w-2 h-2 rounded-full ${st.dot}`} />
                      <span className={`font-medium ${st.badge}`}>{st.label}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                    {boat.description}
                  </p>

                  {/* Vessel Specs Grid */}
                  <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950 p-3 rounded-lg border border-slate-800/80 font-mono">
                    <div>
                      <span className="text-slate-400 text-[11px] block font-sans">Power & Engines</span>
                      <span className="text-white text-xs truncate block">{boat.engines}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[11px] block font-sans">Capacity / LOA</span>
                      <span className="text-white text-xs block">{boat.capacity} Guests · {boat.lengthFt}ft</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[11px] block font-sans">Engine Hours</span>
                      <span className="text-slate-200 text-xs tabular-nums block">{boat.engineHours.toFixed(1)} hrs</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[11px] block font-sans">Fuel Level</span>
                      <span className={`text-xs tabular-nums block ${boat.currentFuelLevelPct < 50 ? 'text-amber-400' : 'text-emerald-400'}`}>
                        {boat.currentFuelLevelPct}% ({Math.round(boat.fuelCapacityGal * (boat.currentFuelLevelPct / 100))} Gal)
                      </span>
                    </div>
                  </div>

                  {/* Electronics & Amenities */}
                  <div className="space-y-1">
                    <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">
                      Navigation & Rigging
                    </span>
                    <div className="flex flex-wrap gap-1 text-[11px] text-slate-400">
                      {boat.electronics.map((item, idx) => (
                        <span key={idx}>
                          {item}
                          {idx < boat.electronics.length - 1 && <span className="ml-1 text-slate-600">·</span>}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer Berth & Booking Button */}
                <div className="px-5 py-3.5 bg-slate-950/60 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div className="text-slate-400 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{boat.homeSlip}</span>
                  </div>

                  {boat.status === 'available' ? (
                    <button
                      onClick={() => handleOpenBooking(boat)}
                      className="px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg transition-colors cursor-pointer"
                    >
                      Reserve Boat
                    </button>
                  ) : boat.status === 'on_water' ? (
                    <span className="text-cyan-400 font-mono text-[11px]">
                      Underway (Return ~13:30)
                    </span>
                  ) : (
                    <span className="text-slate-400 italic text-[11px]">
                      {boat.status === 'reserved' ? 'Scheduled Today' : 'Maintenance Bay'}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 2: Dispatch Board & Float Plans */}
      {activeTab === 'trips' && (
        <div className="space-y-6">
          
          {/* Active Underway Section */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                <h3 className="text-sm font-semibold text-white tracking-tight">
                  Active Trips Underway ({activeOnWaterTrips.length})
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                Monitoring VHF Emergency Ch 16 & Marina Ch 68
              </span>
            </div>

            {activeOnWaterTrips.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                No club vessels currently dispatched on open water.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeOnWaterTrips.map(res => {
                  const boat = boats.find(b => b.id === res.boatId);
                  const member = members.find(m => m.id === res.memberId);

                  return (
                    <div 
                      key={res.id} 
                      className="bg-slate-950 border border-cyan-500/40 rounded-lg p-4 space-y-3"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="text-sm font-bold text-white flex items-center gap-2">
                            <Ship className="w-4 h-4 text-cyan-400" />
                            {boat?.name}
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5">
                            Member: <span className="text-slate-200 font-medium">{member?.fullName}</span>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-xs font-mono text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
                            Departed {res.actualDepartureTime || res.departureTime}
                          </span>
                          <span className="text-[11px] text-slate-400 block mt-1">
                            Est. Return: {res.estimatedReturnTime}
                          </span>
                        </div>
                      </div>

                      {/* Float Plan Data */}
                      <div className="bg-slate-900/80 p-3 rounded border border-slate-800 text-xs space-y-1.5">
                        <div className="flex items-center gap-1.5 text-slate-200 font-medium">
                          <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Destination: {res.floatPlan.destination}</span>
                        </div>
                        <div className="text-slate-400 text-[11px] flex items-center gap-3">
                          <span>{res.floatPlan.crewCount} Persons on board</span>
                          <span aria-hidden="true">·</span>
                          <span>{res.floatPlan.lifeJacketsCount} Life jackets verified</span>
                        </div>
                        <div className="text-slate-400 text-[11px]">
                          Shore contact: {res.floatPlan.shoreContactName} {res.floatPlan.shoreContactPhone}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                        <span className="text-slate-400 font-mono">
                          Initial Meter: {res.startingEngineHours} hrs
                        </span>
                        <button
                          onClick={() => handleStartCheckin(res)}
                          className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-lg transition-colors cursor-pointer"
                        >
                          Check In & Inspect Return
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Confirmed Upcoming Reservations */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-white tracking-tight border-b border-slate-800 pb-3">
              Upcoming Reservations & Float Plans ({upcomingReservations.length})
            </h3>

            {upcomingReservations.length === 0 ? (
              <div className="text-center py-6 text-slate-400 text-xs">
                No upcoming scheduled trips for today.
              </div>
            ) : (
              <div className="divide-y divide-slate-800">
                {upcomingReservations.map(res => {
                  const boat = boats.find(b => b.id === res.boatId);
                  const member = members.find(m => m.id === res.memberId);

                  return (
                    <div key={res.id} className="py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{boat?.name}</span>
                          <span className="text-slate-400">({boat?.model})</span>
                          <span className="text-slate-600">·</span>
                          <span className="font-semibold text-cyan-400 capitalize">{res.timeSlot} Slot</span>
                        </div>
                        <div className="text-slate-300">
                          Chartered by <span className="font-medium text-white">{member?.fullName}</span> · Date: {res.date} ({res.departureTime} – {res.estimatedReturnTime})
                        </div>
                        <div className="text-slate-400 text-[11px]">
                          Destination: {res.floatPlan.destination} ({res.floatPlan.crewCount} crew)
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleStartDispatch(res)}
                          className="px-3.5 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <Play className="w-3.5 h-3.5" /> Dispatch Vessel
                        </button>
                        <button
                          onClick={() => {
                            if (confirm('Cancel this reservation and credit back booking points?')) {
                              cancelReservation(res.id);
                            }
                          }}
                          className="px-3 py-1.5 text-slate-400 hover:text-rose-400 cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Past Trip Log */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-white tracking-tight border-b border-slate-800 pb-3">
              Completed Trip & Fuel Settlement History
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Vessel</th>
                    <th className="py-2.5 px-3">Member</th>
                    <th className="py-2.5 px-3">Destination</th>
                    <th className="py-2.5 px-3 text-right">Engine Time</th>
                    <th className="py-2.5 px-3 text-right">Fuel Reconciled</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {pastTrips.map(res => {
                    const boat = boats.find(b => b.id === res.boatId);
                    const member = members.find(m => m.id === res.memberId);
                    return (
                      <tr key={res.id} className="hover:bg-slate-800/40">
                        <td className="py-2.5 px-3 font-mono text-slate-400">{res.date}</td>
                        <td className="py-2.5 px-3 font-semibold text-white">{boat?.name}</td>
                        <td className="py-2.5 px-3">{member?.fullName}</td>
                        <td className="py-2.5 px-3 text-slate-400">{res.floatPlan.destination}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                          {res.startingEngineHours && res.returnEngineHours
                            ? `${(res.returnEngineHours - res.startingEngineHours).toFixed(1)} hrs`
                            : '—'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-amber-300">
                          {res.fuelBurnedGal ? `${res.fuelBurnedGal} Gal ($${res.fuelBilledAmount?.toFixed(2)})` : '—'}
                        </td>
                        <td className="py-2.5 px-3 capitalize font-medium text-emerald-400">
                          {res.status}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* Modal: Book Club Vessel & Float Plan */}
      {showBookingModal && selectedBoatForBooking && (
        <Modal
          isOpen={showBookingModal}
          onClose={() => setShowBookingModal(false)}
          title={`Reserve Club Vessel: ${selectedBoatForBooking.name}`}
          subtitle={`${selectedBoatForBooking.model} · Capacity: ${selectedBoatForBooking.capacity} passengers`}
        >
          <form onSubmit={handleSubmitBooking} className="space-y-4 text-xs">
            
            {/* Member and Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Club Member</label>
                <select
                  value={bookMemberId}
                  onChange={e => setBookMemberId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
                  required
                >
                  {members.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.fullName} ({m.memberTier.replace('_', ' ')}) - {m.remainingBookingPoints} tokens
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Reservation Date</label>
                <input
                  type="date"
                  value={bookDate}
                  onChange={e => setBookDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>
            </div>

            {/* Time slot */}
            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Trip Time Window</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'morning', label: 'Morning Run', time: '08:00 – 13:00' },
                  { id: 'afternoon', label: 'Sunset Cruise', time: '14:00 – 19:00' },
                  { id: 'fullday', label: 'Full Day Cruise', time: '08:00 – 19:00' }
                ].map(slot => (
                  <button
                    type="button"
                    key={slot.id}
                    onClick={() => setBookSlot(slot.id as TimeSlot)}
                    className={`p-2.5 rounded-lg border text-left cursor-pointer transition-colors ${
                      bookSlot === slot.id
                        ? 'border-cyan-500 bg-cyan-950/30 text-white'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="font-semibold block">{slot.label}</span>
                    <span className="text-[11px] font-mono text-slate-400 block mt-0.5">{slot.time}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Mandatory USCG Float Plan Section */}
            <div className="border border-slate-800 rounded-lg p-3.5 bg-slate-950 space-y-3">
              <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>USCG Boating Safety & Float Plan</span>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Intended Destination / Cruising Waters</label>
                <input
                  type="text"
                  value={destination}
                  onChange={e => setDestination(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Total Souls On Board (Crew)</label>
                  <input
                    type="number"
                    min="1"
                    max={selectedBoatForBooking.capacity}
                    value={crewCount}
                    onChange={e => setCrewCount(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Coast Guard Approved PFDs</label>
                  <input
                    type="number"
                    min={crewCount}
                    value={lifeJackets}
                    onChange={e => setLifeJackets(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100 font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Emergency Shore Contact Name & Phone</label>
                <input
                  type="text"
                  value={shoreContact}
                  onChange={e => setShoreContact(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Float Plan Notes</label>
                <input
                  type="text"
                  value={floatNotes}
                  onChange={e => setFloatNotes(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100"
                />
              </div>

              <label className="flex items-center gap-2 text-slate-300 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={safetyBriefing}
                  onChange={e => setSafetyBriefing(e.target.checked)}
                  className="rounded border-slate-700 accent-cyan-500"
                  required
                />
                <span>Member certifies valid boater license, sober skipper pledge, and marine weather check.</span>
              </label>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowBookingModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer shadow-sm"
              >
                Confirm Reservation & Log Float Plan
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Modal: Dispatch Vessel */}
      {showDispatchModal && selectedResForAction && (
        <Modal
          isOpen={showDispatchModal}
          onClose={() => setShowDispatchModal(false)}
          title="Dispatch Vessel Departure"
          subtitle="Pre-departure dockmaster checklist & engine meter log"
        >
          <form onSubmit={handleExecuteDispatch} className="space-y-4 text-xs">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-1">
              <div className="font-semibold text-white">Pre-Flight Safety Inspection:</div>
              <div className="text-slate-300">✓ Life jackets and throwable ring on board</div>
              <div className="text-slate-300">✓ VHF DSC radio operational on Ch 16 / Ch 68</div>
              <div className="text-slate-300">✓ Bilge pumps, navigation lights, horn tested</div>
              <div className="text-slate-300">✓ Full fuel tank verified by dockhand</div>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Starting Engine Tachometer Hours</label>
              <input
                type="number"
                step="0.1"
                value={startHours}
                onChange={e => setStartHours(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-base font-mono text-white"
                required
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowDispatchModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer"
              >
                Clear for Departure
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Modal: Checkin & Fuel Settlement */}
      {showCheckinModal && selectedResForAction && (
        <Modal
          isOpen={showCheckinModal}
          onClose={() => setShowCheckinModal(false)}
          title="Return Check-In & Fuel Settlement"
          subtitle="Record engine hours and fuel replenishment billed to member folio"
        >
          <form onSubmit={handleExecuteCheckin} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Return Engine Hours</label>
                <input
                  type="number"
                  step="0.1"
                  value={returnHours}
                  onChange={e => setReturnHours(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Fuel Consumed (Gallons)</label>
                <input
                  type="number"
                  step="0.1"
                  value={fuelBurned}
                  onChange={e => setFuelBurned(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono text-white"
                  required
                />
              </div>
            </div>

            <div className="p-3 bg-cyan-950/20 border border-cyan-800/40 rounded-lg text-xs space-y-1">
              <div className="font-semibold text-cyan-300">Fuel Reconciliation Breakdown:</div>
              <div className="text-slate-300">
                • {fuelBurned} gal @ ${fuelInventory.gasPricePerGal}/gal (Rec-90 Marine Non-Ethanol)
              </div>
              <div className="text-white font-mono font-bold">
                Total Folio Charge: ${(fuelBurned * fuelInventory.gasPricePerGal).toFixed(2)} USD
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Post-Trip Hull & Equipment Inspection Notes</label>
              <textarea
                rows={2}
                value={checkinNotes}
                onChange={e => setCheckinNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowCheckinModal(false)}
                className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-lg cursor-pointer"
              >
                Complete Return & Charge Folio
              </button>
            </div>
          </form>
        </Modal>
      )}

    </div>
  );
};
