import React, { useState } from 'react';
import { useMarina } from '../context/MarinaContext';
import { Modal } from './Modal';
import { 
  Anchor, 
  Ship, 
  Zap, 
  Droplet, 
  Calendar, 
  CreditCard, 
  ShieldCheck, 
  Waves, 
  Compass, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  ArrowRight,
  LifeBuoy
} from 'lucide-react';

interface MemberPortalProps {
  onNavigateFleet: () => void;
  onNavigateBilling: () => void;
}

export const MemberPortalView: React.FC<MemberPortalProps> = ({
  onNavigateFleet,
  onNavigateBilling
}) => {
  const { 
    members, 
    vessels, 
    slips, 
    invoices, 
    reservations, 
    boats, 
    selectedMemberId, 
    markInvoicePaid,
    addHarborLog 
  } = useMarina();

  const [showServiceRequestModal, setShowServiceRequestModal] = useState<boolean>(false);
  const [serviceType, setServiceType] = useState<string>('Dockside Blackwater Pump-out');
  const [serviceNotes, setServiceNotes] = useState<string>('Please pump holding tank at slip tomorrow morning.');
  const [requestedSuccess, setRequestedSuccess] = useState<boolean>(false);

  const currentMember = members.find(m => m.id === selectedMemberId) || members[0];
  const memberVessels = vessels.filter(v => v.ownerMemberId === currentMember.id);
  const assignedSlip = slips.find(s => s.id === currentMember.assignedSlipId);
  const memberInvoices = invoices.filter(i => i.memberId === currentMember.id);
  const pendingInvoices = memberInvoices.filter(i => i.status !== 'paid');
  const memberReservations = reservations.filter(r => r.memberId === currentMember.id);

  const handleRequestService = (e: React.FormEvent) => {
    e.preventDefault();
    addHarborLog(
      'pumpout',
      `Member service requested by ${currentMember.fullName}: ${serviceType} at ${assignedSlip ? assignedSlip.code : 'Berth'}. Notes: ${serviceNotes}`,
      'nominal'
    );
    setRequestedSuccess(true);
    setTimeout(() => {
      setRequestedSuccess(false);
      setShowServiceRequestModal(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 rounded-xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-cyan-400 font-semibold uppercase tracking-wider">
            Member Self-Service Berth Portal
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Welcome aboard, {currentMember.fullName}
          </h2>
          <p className="text-xs text-slate-300">
            {currentMember.memberTier.replace('_', ' ').toUpperCase()} · Account #{currentMember.id} · Member since {currentMember.memberSince}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowServiceRequestModal(true)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <LifeBuoy className="w-4 h-4 text-cyan-400" />
            Request Dock Assistance
          </button>
          <button
            onClick={onNavigateFleet}
            className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <Calendar className="w-4 h-4" />
            Book Club Vessel
          </button>
        </div>
      </div>

      {/* Primary 3-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Column 1: Assigned Slip & Utilities */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Anchor className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-white tracking-tight">
                My Berth Slip & Utilities
              </h3>
            </div>
            {assignedSlip && (
              <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
                {assignedSlip.code}
              </span>
            )}
          </div>

          {assignedSlip ? (
            <div className="space-y-4 text-xs">
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-bold text-white text-base font-mono">{assignedSlip.code}</span>
                    <span className="text-slate-400 text-xs block">{assignedSlip.pier}</span>
                  </div>
                  <span className="font-mono text-cyan-400 font-bold text-sm">
                    ${assignedSlip.monthlyRate}/mo
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-slate-300 font-mono text-[11px] pt-1">
                  <div>Max LOA: {assignedSlip.lengthMaxFt}ft</div>
                  <div>Beam: {assignedSlip.beamMaxFt}ft</div>
                  <div>Depth: {assignedSlip.depthMLLWFt}ft MLLW</div>
                  <div>Power: {assignedSlip.powerService}</div>
                </div>
              </div>

              {/* Metered Pedestal */}
              <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300 flex items-center gap-1.5 font-medium">
                    <Zap className="w-3.5 h-3.5 text-amber-400" /> Shore Power Usage
                  </span>
                  <span className="font-mono text-slate-400">@ $0.22 / kWh</span>
                </div>

                <div className="flex items-baseline justify-between pt-1">
                  <span className="text-xl font-bold font-mono text-white tabular-nums">
                    {assignedSlip.electricMeterCurrentReading.toLocaleString()} kWh
                  </span>
                  <span className="text-xs text-amber-400 font-mono">
                    +{(assignedSlip.electricMeterCurrentReading - assignedSlip.electricMeterLastReading)} kWh this cycle
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-slate-400 text-xs pt-1">
                <span className="flex items-center gap-1">
                  <Droplet className="w-3.5 h-3.5 text-cyan-400" /> Freshwater hookup active
                </span>
                <span className="text-emerald-400">Lease: Active</span>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400 text-xs space-y-2">
              <p>You do not currently have a permanent berth slip assigned.</p>
              <p className="text-[11px] text-slate-500">Contact the Harbor Master to request a slip lease.</p>
            </div>
          )}
        </div>

        {/* Column 2: My Vessel & Insurance Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Ship className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-white tracking-tight">
                My Registered Craft
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {memberVessels.length} Registered
            </span>
          </div>

          {memberVessels.length > 0 ? (
            <div className="space-y-3">
              {memberVessels.map(v => (
                <div key={v.id} className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-2">
                      <Ship className="w-4 h-4 text-cyan-400" />
                      {v.name}
                    </div>
                    <div className="text-slate-400 text-[11px] mt-0.5">
                      {v.year} {v.makeModel} · {v.vesselType}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-slate-300 font-mono text-[11px] bg-slate-900 p-2.5 rounded">
                    <div>Length: {v.loaFt}ft LOA</div>
                    <div>Beam: {v.beamFt}ft</div>
                    <div>Draft: {v.draftFt}ft</div>
                    <div>Reg: {v.registrationNo}</div>
                  </div>

                  {/* Insurance compliance card */}
                  <div className="pt-2 border-t border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-[11px]">Marine Insurance</span>
                      <span className="text-emerald-400 text-[11px] flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> USCG Verified
                      </span>
                    </div>
                    <div className="text-slate-200 font-medium">
                      {v.insuranceCarrier} · #{v.insurancePolicyNo}
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      Policy renewal due: <span className="font-mono text-slate-300">{v.insuranceExpiry}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400 text-xs">
              No private vessels registered to this member profile.
            </div>
          )}
        </div>

        {/* Column 3: Folio Balance & Quick Pay */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-white tracking-tight">
                Account Statement & Folio
              </h3>
            </div>
            <button
              onClick={onNavigateBilling}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
            >
              All Invoices →
            </button>
          </div>

          <div className="space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
              <span className="text-slate-400 block">Current Balance Outstanding</span>
              <div className="text-2xl font-bold font-mono text-white tabular-nums">
                ${currentMember.balanceDue.toFixed(2)} USD
              </div>
              <div className="text-slate-400 text-[11px]">
                Auto-pay method: {currentMember.paymentMethodOnFile.brand} (...{currentMember.paymentMethodOnFile.last4})
              </div>
            </div>

            {/* Pending Invoices */}
            <div className="space-y-2">
              <span className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold block">
                Pending Charges
              </span>

              {pendingInvoices.length === 0 ? (
                <div className="text-slate-400 text-xs italic py-2">
                  All folios and slip fees are settled. Thank you!
                </div>
              ) : (
                <div className="space-y-2">
                  {pendingInvoices.map(inv => (
                    <div key={inv.id} className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="font-mono font-semibold text-white">{inv.invoiceNumber}</div>
                        <div className="text-slate-400 text-[11px]">Due {inv.dueDate}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-amber-400">${inv.total.toFixed(2)}</div>
                        <button
                          onClick={() => {
                            markInvoicePaid(inv.id, `${currentMember.paymentMethodOnFile.brand} on file (...${currentMember.paymentMethodOnFile.last4})`);
                            alert(`Paid invoice ${inv.invoiceNumber}! Receipt sent to ${currentMember.email}.`);
                          }}
                          className="text-[11px] text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
                        >
                          Pay Now →
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Club Tokens */}
            <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-slate-400 text-[11px] block">Boat Club Reservations</span>
                <span className="text-cyan-400 font-bold font-mono text-sm mt-0.5 block">
                  {currentMember.remainingBookingPoints} Tokens Remaining
                </span>
              </div>
              <button
                onClick={onNavigateFleet}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded text-xs font-semibold cursor-pointer"
              >
                Book Boat
              </button>
            </div>

          </div>
        </div>

      </div>

      {/* Member Service Request Modal */}
      {showServiceRequestModal && (
        <Modal
          isOpen={showServiceRequestModal}
          onClose={() => setShowServiceRequestModal(false)}
          title="Request Dockside Marina Service"
          subtitle="Dock hands and yard crew will dispatch to your slip"
        >
          {requestedSuccess ? (
            <div className="text-center py-6 space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <h3 className="text-sm font-semibold text-white">Service Request Logged</h3>
              <p className="text-xs text-slate-400">Harbor Master notified on VHF Ch 68. Crew will attend your slip.</p>
            </div>
          ) : (
            <form onSubmit={handleRequestService} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Service Type</label>
                <select
                  value={serviceType}
                  onChange={e => setServiceType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="Dockside Blackwater Pump-out">Dockside Blackwater Pump-out ($45.00)</option>
                  <option value="Freshwater Tank Top-Off & Washdown">Freshwater Tank Top-Off & Washdown</option>
                  <option value="Line Handling & Docking Assistance">Line Handling & Docking Assistance (Arrival / Departure)</option>
                  <option value="Shore Power Pedestal Inspection">Shore Power Pedestal Inspection</option>
                  <option value="Travelift Yard Haul-Out Scheduling">Travelift Yard Haul-Out Scheduling</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Specific Instructions / Preferred Time</label>
                <textarea
                  rows={3}
                  value={serviceNotes}
                  onChange={e => setServiceNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowServiceRequestModal(false)}
                  className="px-3.5 py-1.5 bg-slate-800 text-slate-300 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold rounded-lg cursor-pointer shadow-sm"
                >
                  Submit Dock Service Request
                </button>
              </div>
            </form>
          )}
        </Modal>
      )}

    </div>
  );
};
