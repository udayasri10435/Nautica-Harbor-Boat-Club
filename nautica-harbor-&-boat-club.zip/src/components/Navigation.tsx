import React from 'react';
import { useMarina } from '../context/MarinaContext';
import { Anchor, Shield, User, RotateCcw, AlertTriangle, Compass } from 'lucide-react';

interface NavigationProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenQuickAction: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentTab,
  onSelectTab,
  onOpenQuickAction
}) => {
  const { activeRole, setActiveRole, selectedMemberId, setSelectedMemberId, members, conditions, resetToDemoData } = useMarina();

  const navLinks = [
    { id: 'basin', label: 'Basin & Slips' },
    { id: 'fleet', label: 'Club Fleet & Trips' },
    { id: 'members', label: 'Members & Vessels' },
    { id: 'billing', label: 'Billing & Folios' },
    { id: 'harbor', label: 'Harbor Operations' }
  ];

  const currentMember = members.find(m => m.id === selectedMemberId);

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
        
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-cyan-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Anchor className="w-4 h-4" />
          </div>
          <button 
            onClick={() => onSelectTab('basin')}
            className="text-lg font-bold tracking-tight text-white hover:text-cyan-400 transition-colors cursor-pointer text-left"
          >
            Nautica Harbor & Boat Club
          </button>
        </div>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
          {navLinks.map(link => (
            <button
              key={link.id}
              onClick={() => onSelectTab(link.id)}
              className={`transition-colors whitespace-nowrap cursor-pointer py-1 border-b-2 text-sm ${
                currentTab === link.id
                  ? 'text-cyan-400 border-cyan-500 font-semibold'
                  : 'text-slate-300 border-transparent hover:text-white hover:border-slate-600'
              }`}
            >
              {link.label}
            </button>
          ))}
          {activeRole === 'member' && (
            <button
              onClick={() => onSelectTab('member_portal')}
              className={`transition-colors whitespace-nowrap cursor-pointer py-1 border-b-2 text-sm ${
                currentTab === 'member_portal'
                  ? 'text-cyan-400 border-cyan-500 font-semibold'
                  : 'text-emerald-400 border-transparent hover:text-emerald-300 hover:border-emerald-500'
              }`}
            >
              My Member Berth
            </button>
          )}
        </nav>

        {/* Zone 3: 1-2 primary actions & role toggle */}
        <div className="flex items-center gap-3 shrink-0">
          
          {/* Quick weather status pill-free */}
          <div className="hidden xl:flex items-center gap-2 text-xs text-slate-400 font-mono">
            <Compass className="w-3.5 h-3.5 text-cyan-400" />
            <span>{conditions.windSpeedKts} kts {conditions.windDirection.split(' ')[0]}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Tide: {conditions.tideHeightFt}ft {conditions.tideState}</span>
            {conditions.harborFlag !== 'green' && (
              <>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-amber-400 flex items-center gap-1 font-sans text-xs">
                  <AlertTriangle className="w-3 h-3" /> Small Craft
                </span>
              </>
            )}
          </div>

          {/* Role switcher toggle */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs">
            <button
              onClick={() => {
                setActiveRole('harbor_master');
                if (currentTab === 'member_portal') onSelectTab('basin');
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                activeRole === 'harbor_master'
                  ? 'bg-slate-800 text-cyan-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Harbor Master & Admin Console"
            >
              <Shield className="w-3 h-3" />
              <span className="hidden sm:inline">Harbor Master</span>
            </button>
            <button
              onClick={() => {
                setActiveRole('member');
                onSelectTab('member_portal');
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                activeRole === 'member'
                  ? 'bg-slate-800 text-emerald-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Member Self-Service Portal"
            >
              <User className="w-3 h-3" />
              <span className="hidden sm:inline">Member View</span>
            </button>
          </div>

          {/* If in member mode, let user switch which member they are testing */}
          {activeRole === 'member' && (
            <select
              value={selectedMemberId}
              onChange={e => setSelectedMemberId(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-xs text-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-cyan-500"
              title="Switch Active Member Profile"
            >
              {members.map(m => (
                <option key={m.id} value={m.id}>
                  {m.fullName} ({m.memberTier.replace('_', ' ')})
                </option>
              ))}
            </select>
          )}

          {/* Primary Action Button */}
          <button
            onClick={onOpenQuickAction}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-sm shadow-cyan-900/30"
          >
            + Action
          </button>

          {/* Reset Demo Data button */}
          <button
            onClick={() => {
              if (confirm('Reset marina data to initial demo state?')) {
                resetToDemoData();
              }
            }}
            title="Reset to fresh demo data"
            className="p-1.5 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

        </div>
      </div>

      {/* Mobile navigation row */}
      <div className="lg:hidden flex items-center gap-4 overflow-x-auto pt-2.5 border-t border-slate-800/60 mt-2 text-xs">
        {navLinks.map(link => (
          <button
            key={link.id}
            onClick={() => onSelectTab(link.id)}
            className={`whitespace-nowrap pb-1 border-b-2 ${
              currentTab === link.id
                ? 'text-cyan-400 border-cyan-500 font-semibold'
                : 'text-slate-400 border-transparent'
            }`}
          >
            {link.label}
          </button>
        ))}
        {activeRole === 'member' && (
          <button
            onClick={() => onSelectTab('member_portal')}
            className={`whitespace-nowrap pb-1 border-b-2 ${
              currentTab === 'member_portal'
                ? 'text-emerald-400 border-emerald-500 font-semibold'
                : 'text-emerald-400 border-transparent'
            }`}
          >
            My Berth
          </button>
        )}
      </div>
    </header>
  );
};
