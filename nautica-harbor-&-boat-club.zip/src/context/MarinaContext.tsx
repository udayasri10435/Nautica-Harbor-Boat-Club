import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Slip,
  Vessel,
  Member,
  ClubBoat,
  Reservation,
  Invoice,
  HarborLog,
  FuelInventory,
  MarineConditions,
  SlipWaitlistEntry,
  SlipStatus,
  TimeSlot,
  FloatPlan
} from '../types/marina';
import {
  INITIAL_SLIPS,
  INITIAL_VESSELS,
  INITIAL_MEMBERS,
  INITIAL_CLUB_BOATS,
  INITIAL_RESERVATIONS,
  INITIAL_INVOICES,
  INITIAL_HARBOR_LOGS,
  INITIAL_FUEL_INVENTORY,
  INITIAL_MARINE_CONDITIONS,
  INITIAL_WAITLIST
} from '../data/initialData';

interface MarinaContextType {
  slips: Slip[];
  vessels: Vessel[];
  members: Member[];
  boats: ClubBoat[];
  reservations: Reservation[];
  invoices: Invoice[];
  logs: HarborLog[];
  fuelInventory: FuelInventory;
  conditions: MarineConditions;
  waitlist: SlipWaitlistEntry[];
  activeRole: 'harbor_master' | 'member';
  setActiveRole: (role: 'harbor_master' | 'member') => void;
  selectedMemberId: string;
  setSelectedMemberId: (id: string) => void;

  // Slip actions
  assignSlip: (slipId: string, vesselId: string, memberId: string, leaseType: 'annual' | 'seasonal' | 'transient', rate: number) => void;
  vacateSlip: (slipId: string) => void;
  updateSlipStatus: (slipId: string, status: SlipStatus, notes?: string) => void;
  updateMeterReading: (slipId: string, newReading: number) => void;

  // Member & Vessel actions
  addMember: (memberData: Omit<Member, 'id' | 'memberSince' | 'balanceDue' | 'avatarInitials'>, vesselData?: Omit<Vessel, 'id' | 'ownerMemberId'>) => string;
  updateMemberInsurance: (vesselId: string, policyNo: string, carrier: string, expiry: string) => void;

  // Boat Club actions
  createReservation: (boatId: string, memberId: string, date: string, timeSlot: TimeSlot, floatPlan: FloatPlan) => void;
  dispatchReservation: (reservationId: string, startingEngineHours: number) => void;
  checkinReservation: (reservationId: string, returnEngineHours: number, fuelBurnedGal: number, checkinNotes: string) => void;
  cancelReservation: (reservationId: string) => void;

  // Billing actions
  createInvoice: (memberId: string, lineItems: { description: string; category: any; quantity: number; unitPrice: number }[], dueDate: string) => void;
  markInvoicePaid: (invoiceId: string, paymentMethod: string) => void;

  // Harbor master actions
  addHarborLog: (entryType: any, message: string, severity?: 'nominal' | 'advisory' | 'alert', vhfChannel?: string) => void;
  dispenseFuel: (fuelType: 'diesel' | 'rec90_gas', gallons: number, slipOrVessel: string, memberId?: string) => void;
  setHarborFlag: (flag: 'green' | 'amber' | 'red') => void;

  // Waitlist
  addToWaitlist: (entry: Omit<SlipWaitlistEntry, 'id' | 'requestedDate'>) => void;
  removeFromWaitlist: (id: string) => void;

  resetToDemoData: () => void;
}

const MarinaContext = createContext<MarinaContextType | undefined>(undefined);

const STORAGE_KEYS = {
  SLIPS: 'nautica_slips_v1',
  VESSELS: 'nautica_vessels_v1',
  MEMBERS: 'nautica_members_v1',
  BOATS: 'nautica_boats_v1',
  RESERVATIONS: 'nautica_reservations_v1',
  INVOICES: 'nautica_invoices_v1',
  LOGS: 'nautica_logs_v1',
  FUEL: 'nautica_fuel_v1',
  CONDITIONS: 'nautica_conditions_v1',
  WAITLIST: 'nautica_waitlist_v1',
  ROLE: 'nautica_role_v1',
  ACTIVE_MEMBER: 'nautica_active_member_v1'
};

export const MarinaProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [slips, setSlips] = useState<Slip[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SLIPS);
    return saved ? JSON.parse(saved) : INITIAL_SLIPS;
  });

  const [vessels, setVessels] = useState<Vessel[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.VESSELS);
    return saved ? JSON.parse(saved) : INITIAL_VESSELS;
  });

  const [members, setMembers] = useState<Member[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MEMBERS);
    return saved ? JSON.parse(saved) : INITIAL_MEMBERS;
  });

  const [boats, setBoats] = useState<ClubBoat[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.BOATS);
    return saved ? JSON.parse(saved) : INITIAL_CLUB_BOATS;
  });

  const [reservations, setReservations] = useState<Reservation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RESERVATIONS);
    return saved ? JSON.parse(saved) : INITIAL_RESERVATIONS;
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INVOICES);
    return saved ? JSON.parse(saved) : INITIAL_INVOICES;
  });

  const [logs, setLogs] = useState<HarborLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
    return saved ? JSON.parse(saved) : INITIAL_HARBOR_LOGS;
  });

  const [fuelInventory, setFuelInventory] = useState<FuelInventory>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FUEL);
    return saved ? JSON.parse(saved) : INITIAL_FUEL_INVENTORY;
  });

  const [conditions, setConditions] = useState<MarineConditions>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONDITIONS);
    return saved ? JSON.parse(saved) : INITIAL_MARINE_CONDITIONS;
  });

  const [waitlist, setWaitlist] = useState<SlipWaitlistEntry[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.WAITLIST);
    return saved ? JSON.parse(saved) : INITIAL_WAITLIST;
  });

  const [activeRole, setActiveRole] = useState<'harbor_master' | 'member'>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROLE);
    return (saved as 'harbor_master' | 'member') || 'harbor_master';
  });

  const [selectedMemberId, setSelectedMemberId] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_MEMBER);
    return saved || 'mem-01';
  });

  // Local storage auto-sync
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SLIPS, JSON.stringify(slips));
  }, [slips]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.VESSELS, JSON.stringify(vessels));
  }, [vessels]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BOATS, JSON.stringify(boats));
  }, [boats]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.RESERVATIONS, JSON.stringify(reservations));
  }, [reservations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FUEL, JSON.stringify(fuelInventory));
  }, [fuelInventory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONDITIONS, JSON.stringify(conditions));
  }, [conditions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WAITLIST, JSON.stringify(waitlist));
  }, [waitlist]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLE, activeRole);
  }, [activeRole]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_MEMBER, selectedMemberId);
  }, [selectedMemberId]);

  // Slip actions
  const assignSlip = (
    slipId: string,
    vesselId: string,
    memberId: string,
    leaseType: 'annual' | 'seasonal' | 'transient',
    rate: number
  ) => {
    const slip = slips.find(s => s.id === slipId);
    const vessel = vessels.find(v => v.id === vesselId);
    const member = members.find(m => m.id === memberId);

    setSlips(prev =>
      prev.map(s => {
        if (s.id === slipId) {
          return {
            ...s,
            status: 'occupied',
            currentVesselId: vesselId,
            currentMemberId: memberId,
            leaseType,
            monthlyRate: rate,
            notes: `Assigned to ${vessel ? vessel.name : 'vessel'} (${member ? member.fullName : 'member'})`
          };
        }
        return s;
      })
    );

    setMembers(prev =>
      prev.map(m => {
        if (m.id === memberId) {
          return { ...m, assignedSlipId: slipId };
        }
        return m;
      })
    );

    // Harbor log
    addHarborLog(
      'arrival',
      `Slip ${slip?.code} assigned to vessel ${vessel?.name || 'Vessel'} under ${leaseType} lease.`,
      'nominal'
    );
  };

  const vacateSlip = (slipId: string) => {
    const slip = slips.find(s => s.id === slipId);
    const memberId = slip?.currentMemberId;

    setSlips(prev =>
      prev.map(s => {
        if (s.id === slipId) {
          return {
            ...s,
            status: 'vacant',
            currentVesselId: undefined,
            currentMemberId: undefined,
            leaseType: 'none',
            notes: `Vacated on ${new Date().toLocaleDateString()}`
          };
        }
        return s;
      })
    );

    if (memberId) {
      setMembers(prev =>
        prev.map(m => {
          if (m.id === memberId && m.assignedSlipId === slipId) {
            return { ...m, assignedSlipId: undefined };
          }
          return m;
        })
      );
    }

    addHarborLog('departure', `Slip ${slip?.code} vacated and marked vacant for inspection.`, 'nominal');
  };

  const updateSlipStatus = (slipId: string, status: SlipStatus, notes?: string) => {
    setSlips(prev =>
      prev.map(s => {
        if (s.id === slipId) {
          return {
            ...s,
            status,
            notes: notes !== undefined ? notes : s.notes
          };
        }
        return s;
      })
    );
  };

  const updateMeterReading = (slipId: string, newReading: number) => {
    setSlips(prev =>
      prev.map(s => {
        if (s.id === slipId) {
          return {
            ...s,
            electricMeterLastReading: s.electricMeterCurrentReading,
            electricMeterCurrentReading: newReading
          };
        }
        return s;
      })
    );
  };

  // Member & Vessel actions
  const addMember = (
    memberData: Omit<Member, 'id' | 'memberSince' | 'balanceDue' | 'avatarInitials'>,
    vesselData?: Omit<Vessel, 'id' | 'ownerMemberId'>
  ) => {
    const newMemberId = `mem-${Date.now().toString().slice(-4)}`;
    const initials = memberData.fullName
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);

    const newMember: Member = {
      ...memberData,
      id: newMemberId,
      memberSince: new Date().toISOString().split('T')[0],
      balanceDue: 0,
      avatarInitials: initials
    };

    setMembers(prev => [newMember, ...prev]);

    if (vesselData) {
      const newVesselId = `ves-${Date.now().toString().slice(-4)}`;
      const newVessel: Vessel = {
        ...vesselData,
        id: newVesselId,
        ownerMemberId: newMemberId
      };
      setVessels(prev => [newVessel, ...prev]);
    }

    addHarborLog('nominal', `New member profile created for ${memberData.fullName} (${memberData.memberTier}).`, 'nominal');

    return newMemberId;
  };

  const updateMemberInsurance = (vesselId: string, policyNo: string, carrier: string, expiry: string) => {
    setVessels(prev =>
      prev.map(v => {
        if (v.id === vesselId) {
          return {
            ...v,
            insurancePolicyNo: policyNo,
            insuranceCarrier: carrier,
            insuranceExpiry: expiry,
            insuranceVerified: true
          };
        }
        return v;
      })
    );
  };

  // Boat club actions
  const createReservation = (
    boatId: string,
    memberId: string,
    date: string,
    timeSlot: TimeSlot,
    floatPlan: FloatPlan
  ) => {
    const newReservationId = `res-${Date.now().toString().slice(-4)}`;
    const depTime = timeSlot === 'morning' ? '08:00' : timeSlot === 'afternoon' ? '14:00' : '08:00';
    const retTime = timeSlot === 'morning' ? '13:00' : timeSlot === 'afternoon' ? '19:00' : '19:00';

    const newRes: Reservation = {
      id: newReservationId,
      boatId,
      memberId,
      date,
      timeSlot,
      departureTime: depTime,
      estimatedReturnTime: retTime,
      status: 'confirmed',
      floatPlan
    };

    setReservations(prev => [newRes, ...prev]);

    // Deduct member token
    setMembers(prev =>
      prev.map(m => {
        if (m.id === memberId && m.remainingBookingPoints > 0) {
          return { ...m, remainingBookingPoints: m.remainingBookingPoints - 1 };
        }
        return m;
      })
    );

    const boat = boats.find(b => b.id === boatId);
    const member = members.find(m => m.id === memberId);
    addHarborLog(
      'departure',
      `Boat Club reservation confirmed for ${member?.fullName || 'Member'} on ${boat?.name || 'Vessel'} (${date}, ${timeSlot}). Float plan logged to ${floatPlan.destination}.`,
      'nominal'
    );
  };

  const dispatchReservation = (reservationId: string, startingEngineHours: number) => {
    const res = reservations.find(r => r.id === reservationId);
    if (!res) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setReservations(prev =>
      prev.map(r => {
        if (r.id === reservationId) {
          return {
            ...r,
            status: 'dispatched',
            actualDepartureTime: timeStr,
            startingEngineHours
          };
        }
        return r;
      })
    );

    // Update boat status
    setBoats(prev =>
      prev.map(b => {
        if (b.id === res.boatId) {
          return { ...b, status: 'on_water', engineHours: startingEngineHours };
        }
        return b;
      })
    );

    const boat = boats.find(b => b.id === res.boatId);
    addHarborLog('departure', `Club vessel ${boat?.name} dispatched with ${res.floatPlan.crewCount} on board. Destination: ${res.floatPlan.destination}.`, 'nominal');
  };

  const checkinReservation = (
    reservationId: string,
    returnEngineHours: number,
    fuelBurnedGal: number,
    checkinNotes: string
  ) => {
    const res = reservations.find(r => r.id === reservationId);
    if (!res) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const fuelCost = Number((fuelBurnedGal * fuelInventory.gasPricePerGal).toFixed(2));

    setReservations(prev =>
      prev.map(r => {
        if (r.id === reservationId) {
          return {
            ...r,
            status: 'completed',
            actualReturnTime: timeStr,
            returnEngineHours,
            fuelBurnedGal,
            fuelBilledAmount: fuelCost,
            checkinNotes
          };
        }
        return r;
      })
    );

    // Update boat
    setBoats(prev =>
      prev.map(b => {
        if (b.id === res.boatId) {
          const newLevel = Math.max(20, b.currentFuelLevelPct - Math.round((fuelBurnedGal / b.fuelCapacityGal) * 100));
          return {
            ...b,
            status: 'available',
            engineHours: returnEngineHours,
            currentFuelLevelPct: newLevel
          };
        }
        return b;
      })
    );

    // Generate fuel invoice line item for member
    if (fuelCost > 0) {
      createInvoice(
        res.memberId,
        [
          {
            description: `Fuel top-off after club voyage (${fuelBurnedGal} Gal @ $${fuelInventory.gasPricePerGal}/gal)`,
            category: 'fuel',
            quantity: fuelBurnedGal,
            unitPrice: fuelInventory.gasPricePerGal
          }
        ],
        new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
      );
    }

    const boat = boats.find(b => b.id === res.boatId);
    addHarborLog(
      'arrival',
      `Club vessel ${boat?.name} returned and checked in. Engine hours: ${returnEngineHours} hrs. Fuel consumed: ${fuelBurnedGal} gal.`,
      'nominal'
    );
  };

  const cancelReservation = (reservationId: string) => {
    const res = reservations.find(r => r.id === reservationId);
    if (!res) return;

    setReservations(prev =>
      prev.map(r => {
        if (r.id === reservationId) {
          return { ...r, status: 'cancelled' };
        }
        return r;
      })
    );

    // Refund token
    setMembers(prev =>
      prev.map(m => {
        if (m.id === res.memberId) {
          return { ...m, remainingBookingPoints: m.remainingBookingPoints + 1 };
        }
        return m;
      })
    );
  };

  // Billing
  const createInvoice = (
    memberId: string,
    lineItemsData: { description: string; category: any; quantity: number; unitPrice: number }[],
    dueDate: string
  ) => {
    const invNumber = `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const lineItems = lineItemsData.map((li, idx) => ({
      ...li,
      id: `li-${Date.now()}-${idx}`,
      total: Number((li.quantity * li.unitPrice).toFixed(2))
    }));

    const subtotal = Number(lineItems.reduce((acc, curr) => acc + curr.total, 0).toFixed(2));
    const tax = 0;
    const total = subtotal + tax;

    const newInvoice: Invoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: invNumber,
      memberId,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate,
      status: 'pending',
      lineItems,
      subtotal,
      tax,
      total
    };

    setInvoices(prev => [newInvoice, ...prev]);

    // Update member balance
    setMembers(prev =>
      prev.map(m => {
        if (m.id === memberId) {
          return { ...m, balanceDue: Number((m.balanceDue + total).toFixed(2)) };
        }
        return m;
      })
    );

    addHarborLog('nominal', `Invoice ${invNumber} generated ($${total.toLocaleString()}) for folio account.`, 'nominal');
  };

  const markInvoicePaid = (invoiceId: string, paymentMethod: string) => {
    const inv = invoices.find(i => i.id === invoiceId);
    if (!inv) return;

    const paidDate = new Date().toISOString().split('T')[0];

    setInvoices(prev =>
      prev.map(i => {
        if (i.id === invoiceId) {
          return {
            ...i,
            status: 'paid',
            paidAt: paidDate,
            paymentMethod
          };
        }
        return i;
      })
    );

    // Deduct from member balance
    setMembers(prev =>
      prev.map(m => {
        if (m.id === inv.memberId) {
          return { ...m, balanceDue: Math.max(0, Number((m.balanceDue - inv.total).toFixed(2))) };
        }
        return m;
      })
    );

    addHarborLog('nominal', `Payment recorded for ${inv.invoiceNumber} ($${inv.total.toFixed(2)}) via ${paymentMethod}.`, 'nominal');
  };

  // Harbor Master actions
  const addHarborLog = (
    entryType: any,
    message: string,
    severity: 'nominal' | 'advisory' | 'alert' = 'nominal',
    vhfChannel?: string
  ) => {
    const now = new Date();
    const timeStr = `${now.toISOString().split('T')[0]} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const newLog: HarborLog = {
      id: `log-${Date.now()}`,
      timestamp: timeStr,
      entryType,
      message,
      recordedBy: activeRole === 'harbor_master' ? 'Harbor Master' : 'Marina System',
      vhfChannel,
      severity
    };

    setLogs(prev => [newLog, ...prev]);
  };

  const dispenseFuel = (
    fuelType: 'diesel' | 'rec90_gas',
    gallons: number,
    slipOrVessel: string,
    memberId?: string
  ) => {
    const pricePerGal = fuelType === 'diesel' ? fuelInventory.dieselPricePerGal : fuelInventory.gasPricePerGal;
    const totalAmount = Number((gallons * pricePerGal).toFixed(2));

    setFuelInventory(prev => ({
      ...prev,
      dieselGallons: fuelType === 'diesel' ? Math.max(0, prev.dieselGallons - gallons) : prev.dieselGallons,
      gasGallons: fuelType === 'rec90_gas' ? Math.max(0, prev.gasGallons - gallons) : prev.gasGallons
    }));

    addHarborLog(
      'fuel_dock',
      `Dispensed ${gallons} gal of ${fuelType === 'diesel' ? 'Marine Diesel' : 'Rec-90 Marine Gas'} ($${totalAmount.toFixed(2)}) to ${slipOrVessel}.`,
      'nominal',
      'Ch 09'
    );

    // If billed to a member, generate invoice
    if (memberId) {
      createInvoice(
        memberId,
        [
          {
            description: `${fuelType === 'diesel' ? 'Marine Diesel' : 'Rec-90 Non-Ethanol Gas'} - ${slipOrVessel}`,
            category: 'fuel',
            quantity: gallons,
            unitPrice: pricePerGal
          }
        ],
        new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]
      );
    }
  };

  const setHarborFlag = (flag: 'green' | 'amber' | 'red') => {
    setConditions(prev => ({ ...prev, harborFlag: flag }));
    const statusText = flag === 'green' ? 'Normal / Clear Waters' : flag === 'amber' ? 'Small Craft Advisory' : 'Gale / Severe Weather Alert';
    addHarborLog('weather', `Harbor flag status set to ${flag.toUpperCase()}: ${statusText}`, flag === 'green' ? 'nominal' : 'alert');
  };

  const addToWaitlist = (entry: Omit<SlipWaitlistEntry, 'id' | 'requestedDate'>) => {
    const newEntry: SlipWaitlistEntry = {
      ...entry,
      id: `wait-${Date.now()}`,
      requestedDate: new Date().toISOString().split('T')[0]
    };
    setWaitlist(prev => [...prev, newEntry]);
  };

  const removeFromWaitlist = (id: string) => {
    setWaitlist(prev => prev.filter(w => w.id !== id));
  };

  const resetToDemoData = () => {
    setSlips(INITIAL_SLIPS);
    setVessels(INITIAL_VESSELS);
    setMembers(INITIAL_MEMBERS);
    setBoats(INITIAL_CLUB_BOATS);
    setReservations(INITIAL_RESERVATIONS);
    setInvoices(INITIAL_INVOICES);
    setLogs(INITIAL_HARBOR_LOGS);
    setFuelInventory(INITIAL_FUEL_INVENTORY);
    setConditions(INITIAL_MARINE_CONDITIONS);
    setWaitlist(INITIAL_WAITLIST);
    localStorage.clear();
  };

  return (
    <MarinaContext.Provider
      value={{
        slips,
        vessels,
        members,
        boats,
        reservations,
        invoices,
        logs,
        fuelInventory,
        conditions,
        waitlist,
        activeRole,
        setActiveRole,
        selectedMemberId,
        setSelectedMemberId,
        assignSlip,
        vacateSlip,
        updateSlipStatus,
        updateMeterReading,
        addMember,
        updateMemberInsurance,
        createReservation,
        dispatchReservation,
        checkinReservation,
        cancelReservation,
        createInvoice,
        markInvoicePaid,
        addHarborLog,
        dispenseFuel,
        setHarborFlag,
        addToWaitlist,
        removeFromWaitlist,
        resetToDemoData
      }}
    >
      {children}
    </MarinaContext.Provider>
  );
};

export const useMarina = () => {
  const context = useContext(MarinaContext);
  if (!context) {
    throw new Error('useMarina must be used within a MarinaProvider');
  }
  return context;
};
